import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Max payload size for image uploads (multiple photos supported)
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Server-side Gemini client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Helper to sanitize JSON response from Gemini
function cleanJsonText(raw: string): string {
  let cleaned = raw.trim();
  if (cleaned.startsWith('```json')) {
    cleaned = cleaned.replace(/^```json\s*/, '').replace(/\s*```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/\s*```$/, '');
  }
  return cleaned.trim();
}

// -------------------------------------------------------------
// API ROUTE 1: Scan Fridge / Pantry / Freezer Photos
// -------------------------------------------------------------
app.post('/api/pantry/scan', async (req: Request, res: Response) => {
  try {
    const { images, storageType } = req.body;
    // images: array of { base64: string, mimeType: string }

    if (!images || !Array.isArray(images) || images.length === 0) {
      return res.status(400).json({ error: 'Please provide at least one photo to scan.' });
    }

    if (!ai) {
      // Intelligent fallback when GEMINI_API_KEY is not configured
      return res.json({
        items: [
          { name: 'Eggs', quantity: 12, unit: 'count', category: 'Dairy & Eggs', daysUntilExpiration: 14, location: storageType || 'fridge', confidence: 0.95 },
          { name: 'Chicken Breast', quantity: 600, unit: 'g', category: 'Meat & Poultry', daysUntilExpiration: 2, location: storageType || 'fridge', confidence: 0.92 },
          { name: 'Greek Yogurt', quantity: 500, unit: 'g', category: 'Dairy & Eggs', daysUntilExpiration: 5, location: storageType || 'fridge', confidence: 0.94 },
          { name: 'Baby Spinach', quantity: 200, unit: 'g', category: 'Produce', daysUntilExpiration: 3, location: storageType || 'fridge', confidence: 0.88 },
          { name: 'Rolled Oats', quantity: 800, unit: 'g', category: 'Grains & Pasta', daysUntilExpiration: 90, location: 'pantry', confidence: 0.96 },
          { name: 'Canned Black Beans', quantity: 2, unit: 'cans', category: 'Canned Goods', daysUntilExpiration: 180, location: 'pantry', confidence: 0.95 },
          { name: 'Olive Oil', quantity: 500, unit: 'ml', category: 'Condiments & Oils', daysUntilExpiration: 180, location: 'pantry', confidence: 0.97 },
        ],
        source: 'simulated_fallback',
        message: 'No GEMINI_API_KEY detected in environment; returned standard sample ingredients. Configure key in Secrets to scan real photos.',
      });
    }

    const contentsParts: any[] = [];

    for (const img of images) {
      const mimeType = img.mimeType || 'image/jpeg';
      const base64Data = img.base64.replace(/^data:[^;]+;base64,/, '');
      contentsParts.push({
        inlineData: {
          mimeType,
          data: base64Data,
        },
      });
    }

    contentsParts.push({
      text: `Analyze all visible food items across these photo(s) of a ${storageType || 'fridge, freezer, or pantry'}.
Identify each unique grocery/food item.
For each item estimate:
- name: clean common grocery name (e.g., "Chicken Breast", "Greek Yogurt", "Bell Peppers")
- quantity: numeric amount estimate
- unit: appropriate unit (e.g., "g", "ml", "count", "cans", "tbsp", "cups", "slices")
- category: one of ["Produce", "Meat & Poultry", "Fish & Seafood", "Dairy & Eggs", "Grains & Pasta", "Canned Goods", "Baking & Spices", "Condiments & Oils", "Frozen", "Snacks", "Beverages", "Other"]
- daysUntilExpiration: estimated shelf life in days from today (e.g. fresh meat/fish 2-3, opened greens 3-4, dairy 7-14, pantry items 60-180, frozen 90-180)
- location: "${storageType || 'fridge'}" (or fridge/pantry/freezer based on appearance)
- confidence: number between 0.5 and 1.0

Return ONLY a valid JSON array matching the schema.`,
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: { parts: contentsParts },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              quantity: { type: Type.NUMBER },
              unit: { type: Type.STRING },
              category: { type: Type.STRING },
              daysUntilExpiration: { type: Type.INTEGER },
              location: { type: Type.STRING },
              confidence: { type: Type.NUMBER },
            },
            required: ['name', 'quantity', 'unit', 'category', 'daysUntilExpiration'],
          },
        },
      },
    });

    const text = response.text || '[]';
    const parsed = JSON.parse(cleanJsonText(text));

    res.json({
      items: parsed,
      source: 'gemini_vision',
    });
  } catch (error: any) {
    console.error('Pantry scan error:', error);
    res.status(500).json({
      error: 'Failed to analyze pantry photo: ' + (error?.message || String(error)),
    });
  }
});

// -------------------------------------------------------------
// API ROUTE 2: Generate 3 Macro-Optimized Recipes
// -------------------------------------------------------------
app.post('/api/recipes/generate', async (req: Request, res: Response) => {
  try {
    const {
      pantryItems,
      remainingMacros, // { calories, protein, carbs, fat }
      preferences, // string[] (e.g., ["keto", "gluten-free"])
      allergies, // string[]
      cookingSkill, // "beginner" | "intermediate" | "advanced"
      timeBudget, // "under 15 min" | "15-30 min" | "30-60 min" | "no limit"
      householdSize, // number
      expiringItems, // string[] items needing urgent use
      customPrompt, // optional custom wish
    } = req.body;

    const remaining = {
      calories: Math.max(50, Math.round(remainingMacros?.calories || 600)),
      protein: Math.max(5, Math.round(remainingMacros?.protein || 45)),
      carbs: Math.max(5, Math.round(remainingMacros?.carbs || 50)),
      fat: Math.max(3, Math.round(remainingMacros?.fat || 20)),
    };

    if (!ai) {
      // High-grade fallback with realistic fitness recipes
      const fallbackRecipes = [
        {
          id: 'rec_' + Date.now() + '_1',
          title: 'Skillet Seared Chicken & Garlic Crisp Greens',
          description: 'High-protein, quick skillet sauté utilizing fresh chicken breast and leafy greens with aromatic garlic.',
          servings: householdSize || 1,
          prepTimeMinutes: 10,
          cookTimeMinutes: 15,
          macrosPerServing: {
            calories: Math.min(remaining.calories, 480),
            protein: Math.min(remaining.protein, 46),
            carbs: Math.min(remaining.carbs, 18),
            fat: Math.min(remaining.fat, 16),
          },
          ingredients: [
            { name: 'Chicken Breast', quantity: 200, unit: 'g', fromPantry: true },
            { name: 'Baby Spinach', quantity: 150, unit: 'g', fromPantry: true },
            { name: 'Olive Oil', quantity: 1, unit: 'tbsp', fromPantry: true },
            { name: 'Garlic Cloves', quantity: 2, unit: 'cloves', fromPantry: false, substitution: '1/2 tsp garlic powder' },
            { name: 'Lemon Juice', quantity: 1, unit: 'tbsp', fromPantry: false, substitution: 'apple cider vinegar' },
          ],
          instructions: [
            { stepNumber: 1, text: 'Pat chicken breasts dry with a paper towel and season liberally with salt and black pepper.', durationMinutes: 2 },
            { stepNumber: 2, text: 'Heat olive oil in a stainless steel or cast iron skillet over medium-high heat until shimmering.', durationMinutes: 2 },
            { stepNumber: 3, text: 'Add chicken breast and sear undisturbed for 6-7 minutes until a deep golden crust forms.', durationMinutes: 7 },
            { stepNumber: 4, text: 'Flip chicken, reduce heat to medium, and cook for another 5-6 minutes until internal temp reaches 165°F (74°C). Transfer to a plate to rest.', durationMinutes: 5 },
            { stepNumber: 5, text: 'In the remaining pan juices, toss minced garlic for 30 seconds, then fold in spinach until wilted. Squeeze fresh lemon over top and serve with sliced chicken.', durationMinutes: 2 },
          ],
          tags: ['High Protein', 'Low Carb', 'Quick Dinner'],
          missingCount: 2,
        },
        {
          id: 'rec_' + Date.now() + '_2',
          title: 'Creamy Greek Yogurt & Protein Power Bowl',
          description: 'Fast, cooling anabolic bowl balanced with slow-digesting carbs and micro-filtered dairy protein.',
          servings: householdSize || 1,
          prepTimeMinutes: 5,
          cookTimeMinutes: 0,
          macrosPerServing: {
            calories: Math.min(remaining.calories, 390),
            protein: Math.min(remaining.protein, 38),
            carbs: Math.min(remaining.carbs, 35),
            fat: Math.min(remaining.fat, 9),
          },
          ingredients: [
            { name: 'Greek Yogurt', quantity: 250, unit: 'g', fromPantry: true },
            { name: 'Rolled Oats', quantity: 40, unit: 'g', fromPantry: true },
            { name: 'Honey or Maple Syrup', quantity: 1, unit: 'tsp', fromPantry: false, substitution: 'Cinnamon or zero-cal sweetener' },
            { name: 'Chia Seeds', quantity: 10, unit: 'g', fromPantry: false, substitution: 'Crushed flax or chopped nuts' },
          ],
          instructions: [
            { stepNumber: 1, text: 'Spoon thick Greek yogurt into a chilled ceramic bowl.', durationMinutes: 1 },
            { stepNumber: 2, text: 'Lightly toast rolled oats in a dry pan for 2 minutes for nutty flavor, or fold directly into yogurt for overnight oat style texture.', durationMinutes: 2 },
            { stepNumber: 3, text: 'Gently fold together, swirl sweetener of choice, and top with chia seeds for sustained satiety.', durationMinutes: 2 },
          ],
          tags: ['No Cook', 'High Protein', 'Post-Workout'],
          missingCount: 2,
        },
        {
          id: 'rec_' + Date.now() + '_3',
          title: 'Hearty Black Bean & Egg Scramble Hash',
          description: 'Nutrient-dense skillet fuel combining whole egg fats with fiber-rich black beans.',
          servings: householdSize || 1,
          prepTimeMinutes: 5,
          cookTimeMinutes: 10,
          macrosPerServing: {
            calories: Math.min(remaining.calories, 420),
            protein: Math.min(remaining.protein, 32),
            carbs: Math.min(remaining.carbs, 42),
            fat: Math.min(remaining.fat, 14),
          },
          ingredients: [
            { name: 'Eggs', quantity: 3, unit: 'count', fromPantry: true },
            { name: 'Canned Black Beans', quantity: 120, unit: 'g', fromPantry: true },
            { name: 'Olive Oil', quantity: 1, unit: 'tsp', fromPantry: true },
            { name: 'Salsa or Hot Sauce', quantity: 2, unit: 'tbsp', fromPantry: false, substitution: 'Pinch of smoked paprika & cayenne' },
          ],
          instructions: [
            { stepNumber: 1, text: 'Rinse and drain canned black beans thoroughly.', durationMinutes: 2 },
            { stepNumber: 2, text: 'Warm olive oil in a non-stick pan over medium heat. Add drained black beans and cook for 3 minutes until hot.', durationMinutes: 3 },
            { stepNumber: 3, text: 'Whisk eggs with a pinch of sea salt in a small bowl, then pour into the pan with beans.', durationMinutes: 1 },
            { stepNumber: 4, text: 'Gently push eggs with a silicone spatula across the skillet to create soft, glossy curds for 2-3 minutes. Remove while still slightly tender.', durationMinutes: 3 },
            { stepNumber: 5, text: 'Plate immediately and spoon over salsa or hot sauce.', durationMinutes: 1 },
          ],
          tags: ['Fiber Rich', 'Vegetarian', 'One Pan'],
          missingCount: 1,
        },
      ];

      return res.json({
        recipes: fallbackRecipes,
        source: 'simulated_fallback',
        message: 'No GEMINI_API_KEY detected; generated high-nutrition pantry suggestions.',
      });
    }

    const pantryNames = Array.isArray(pantryItems)
      ? pantryItems.map((i: any) => `${i.name} (${i.quantity} ${i.unit})`).join(', ')
      : 'Chicken breast, eggs, spinach, olive oil, Greek yogurt, oats, rice, black beans';

    const systemPrompt = `You are an elite sports nutrition chef and culinary strategist.
The user is tracking strict macros.
THEIR REMAINING MACRO BUDGET FOR TODAY:
- Calories: ${remaining.calories} kcal
- Protein: ${remaining.protein} g
- Carbs: ${remaining.carbs} g
- Fat: ${remaining.fat} g

USER PROFILE & PREFERENCES:
- Cooking skill: ${cookingSkill || 'intermediate'}
- Cooking time budget: ${timeBudget || 'under 30 min'}
- Household size: ${householdSize || 1} serving(s)
- Dietary preferences: ${preferences?.join(', ') || 'none'}
- Allergies to strictly avoid: ${allergies?.join(', ') || 'none'}
- Priority ingredients expiring soon: ${expiringItems?.join(', ') || 'none'}
${customPrompt ? `- Specific user request: ${customPrompt}` : ''}

AVAILABLE INGREDIENTS IN USER'S PANTRY:
${pantryNames}

TASK:
Generate exactly 3 diverse, delicious recipe suggestions that fit closely within the user's remaining macros for the day (per serving).
Rules:
1. Maximize use of confirmed pantry ingredients.
2. If a recipe requires 1 or 2 ingredients not in the pantry, mark "fromPantry: false", and specify a convenient pantry substitution if feasible in "substitution".
3. Provide discrete numbered steps (not monolithic paragraphs), each with estimated durationMinutes.
4. Total prep and cook times should adhere to the user's time budget.
5. Accurately calculate the nutrition per serving (calories, protein, carbs, fat).
6. Return valid JSON only adhering strictly to the schema.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: systemPrompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              servings: { type: Type.INTEGER },
              prepTimeMinutes: { type: Type.INTEGER },
              cookTimeMinutes: { type: Type.INTEGER },
              macrosPerServing: {
                type: Type.OBJECT,
                properties: {
                  calories: { type: Type.NUMBER },
                  protein: { type: Type.NUMBER },
                  carbs: { type: Type.NUMBER },
                  fat: { type: Type.NUMBER },
                },
                required: ['calories', 'protein', 'carbs', 'fat'],
              },
              ingredients: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    quantity: { type: Type.NUMBER },
                    unit: { type: Type.STRING },
                    fromPantry: { type: Type.BOOLEAN },
                    substitution: { type: Type.STRING },
                  },
                  required: ['name', 'quantity', 'unit', 'fromPantry'],
                },
              },
              instructions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    stepNumber: { type: Type.INTEGER },
                    text: { type: Type.STRING },
                    durationMinutes: { type: Type.INTEGER },
                  },
                  required: ['stepNumber', 'text'],
                },
              },
              tags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              missingCount: { type: Type.INTEGER },
            },
            required: ['title', 'description', 'servings', 'prepTimeMinutes', 'cookTimeMinutes', 'macrosPerServing', 'ingredients', 'instructions'],
          },
        },
      },
    });

    const text = response.text || '[]';
    const parsed = JSON.parse(cleanJsonText(text));

    const recipesWithIds = parsed.map((r: any, idx: number) => ({
      ...r,
      id: 'rec_' + Date.now() + '_' + idx,
      missingCount: r.missingCount ?? r.ingredients?.filter((i: any) => !i.fromPantry).length ?? 0,
    }));

    res.json({
      recipes: recipesWithIds,
      source: 'gemini',
    });
  } catch (error: any) {
    console.error('Recipe generation error:', error);
    res.status(500).json({
      error: 'Failed to generate recipes: ' + (error?.message || String(error)),
    });
  }
});

// -------------------------------------------------------------
// API ROUTE 3: Plan My Week (3, 5, or 7 Day Dinner Plan)
// -------------------------------------------------------------
app.post('/api/recipes/plan-week', async (req: Request, res: Response) => {
  try {
    const { days = 5, pantryItems, dailyTargetDinnerMacros, preferences, allergies } = req.body;

    if (!ai) {
      // Mock plan for testing
      const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      const plan = Array.from({ length: days }).map((_, i) => ({
        day: dayNames[i] || `Day ${i + 1}`,
        recipeTitle: `Pantry Meal ${i + 1}`,
        macros: {
          calories: 550,
          protein: 45,
          carbs: 40,
          fat: 18,
        },
        primaryPantryItem: 'Pantry Protein & Veg',
        groceriesNeeded: ['Fresh herbs', 'Lemon'],
      }));

      return res.json({ plan, additionalGroceries: ['Fresh herbs', 'Lemon', 'Garlic'] });
    }

    const pantryNames = Array.isArray(pantryItems)
      ? pantryItems.map((i: any) => i.name).join(', ')
      : 'staples';

    const prompt = `Create a ${days}-day dinner meal plan utilizing these pantry items: ${pantryNames}.
Preferences: ${preferences?.join(', ') || 'standard'}. Allergies: ${allergies?.join(', ') || 'none'}.
Target macros per dinner roughly: ~${dailyTargetDinnerMacros?.calories || 600} kcal, ~${dailyTargetDinnerMacros?.protein || 45}g protein, ~${dailyTargetDinnerMacros?.carbs || 50}g carbs, ~${dailyTargetDinnerMacros?.fat || 20}g fat.
Prioritize minimizing extra grocery shopping.
Return JSON with:
- plan: array of objects with: day (string), recipeTitle (string), description (string), prepTimeMinutes (number), macros ({ calories, protein, carbs, fat }), primaryPantryIngredients (array of strings), extraGroceriesNeeded (array of strings)
- masterGroceryList: combined unique list of extra items to buy across the entire week plan.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    const parsed = JSON.parse(cleanJsonText(text));

    res.json(parsed);
  } catch (error: any) {
    console.error('Plan week error:', error);
    res.status(500).json({ error: 'Failed to generate weekly plan: ' + (error?.message || String(error)) });
  }
});

// -------------------------------------------------------------
// Vite middleware in Dev / Static serving in Production
// -------------------------------------------------------------
async function setupServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`PantryMacros server running on port ${PORT} (${isDev ? 'development' : 'production'})`);
  });
}

setupServer().catch((err) => {
  console.error('Fatal server boot error:', err);
});
