export type ActivityLevel =
  | 'sedentary'
  | 'lightly_active'
  | 'moderately_active'
  | 'very_active'
  | 'extra_active';

export type FitnessGoal = 'lose_fat' | 'maintain' | 'build_muscle';

export type CookingSkill = 'beginner' | 'intermediate' | 'advanced';

export type TimeBudget = 'under 15 min' | '15-30 min' | '30-60 min' | 'no limit';

export interface MacroBudget {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface UserProfile {
  name: string;
  age: number;
  sex: 'male' | 'female' | 'other';
  heightCm: number;
  weightKg: number;
  activityLevel: ActivityLevel;
  goal: FitnessGoal;
  targets: MacroBudget;
  dietaryPreferences: string[];
  allergies: string[];
  cookingSkill: CookingSkill;
  householdSize: number;
  timeBudget: TimeBudget;
  onboarded: boolean;
}

export type StorageLocation = 'fridge' | 'pantry' | 'freezer';

export type UrgencyStatus = 'expired' | 'use_soon' | 'fresh';

export interface PantryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  category: string;
  addedDate: string; // ISO
  expirationDate: string; // ISO
  location: StorageLocation;
  confidenceSource?: 'photo_scan' | 'manual' | 'barcode';
}

export interface MealLogEntry {
  id: string;
  date: string; // YYYY-MM-DD
  title: string;
  mealType: 'breakfast' | 'lunch' | 'dinner' | 'snack';
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  quantity?: string;
  recipeId?: string;
  timestamp: string; // ISO
}

export interface RecipeIngredient {
  name: string;
  quantity: number;
  unit: string;
  fromPantry: boolean;
  substitution?: string;
}

export interface RecipeInstruction {
  stepNumber: number;
  text: string;
  durationMinutes?: number;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  servings: number;
  prepTimeMinutes: number;
  cookTimeMinutes: number;
  macrosPerServing: MacroBudget;
  ingredients: RecipeIngredient[];
  instructions: RecipeInstruction[];
  tags: string[];
  favorited: boolean;
  rating: number; // 0 to 5
  personalNotes?: string;
  missingCount: number;
  createdDate: string;
  lastCookedDate?: string;
}

export interface GroceryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  checked: boolean;
  recipeSource?: string;
  category?: string;
}

export interface WeightEntry {
  id: string;
  date: string; // YYYY-MM-DD
  weightKg: number;
}

export interface DayDinnerPlan {
  day: string;
  recipeTitle: string;
  description: string;
  prepTimeMinutes: number;
  macros: MacroBudget;
  primaryPantryIngredients: string[];
  extraGroceriesNeeded: string[];
}
