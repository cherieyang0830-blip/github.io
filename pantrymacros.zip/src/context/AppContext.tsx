import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  GroceryItem,
  MacroBudget,
  MealLogEntry,
  PantryItem,
  Recipe,
  UserProfile,
  WeightEntry,
} from '../types';
import {
  calculateSuggestedMacros,
  getDaysUntilExpiration,
  getTodayDateString,
  getUrgencyStatus,
} from '../utils/nutrition';
import {
  DEFAULT_USER,
  INITIAL_GROCERY,
  INITIAL_MEALS,
  INITIAL_PANTRY,
  INITIAL_RECIPES,
  INITIAL_WEIGHT_LOGS,
} from '../utils/seedData';

interface FoodWasteStats {
  itemsSavedCount: number;
  estimatedMoneySaved: number; // in USD
  estimatedKgSaved: number;
}

interface AppNotification {
  id: string;
  type: 'urgency' | 'reminder' | 'streak';
  message: string;
  timestamp: string;
  actionText?: string;
  actionRoute?: string;
}

interface AppContextType {
  // User profile & targets
  user: UserProfile;
  updateUser: (updates: Partial<UserProfile>) => void;
  recomputeAutoTargets: () => void;

  // Selected date for day browser
  selectedDate: string;
  setSelectedDate: (date: string) => void;
  goToPreviousDay: () => void;
  goToNextDay: () => void;
  goToToday: () => void;

  // Macro metrics for selected date
  todayLogged: MacroBudget;
  remainingMacros: MacroBudget;
  overUnderMacros: MacroBudget;
  streakCount: number;

  // Meals
  meals: MealLogEntry[];
  addMeal: (entry: Omit<MealLogEntry, 'id' | 'timestamp'>) => void;
  updateMeal: (id: string, updates: Partial<MealLogEntry>) => void;
  deleteMeal: (id: string) => void;

  // Pantry
  pantry: PantryItem[];
  addPantryItem: (item: Omit<PantryItem, 'id' | 'addedDate'>) => void;
  updatePantryItem: (id: string, updates: Partial<PantryItem>) => void;
  deletePantryItem: (id: string) => void;
  bulkAddPantryItems: (items: Array<Omit<PantryItem, 'id' | 'addedDate'>>) => void;
  decrementPantryForRecipe: (recipe: Recipe, servingsMultiplier?: number) => number; // returns items used

  // Recipe engine & library
  recipes: Recipe[];
  saveRecipe: (recipe: Recipe) => void;
  toggleFavoriteRecipe: (id: string) => void;
  rateRecipe: (id: string, rating: number) => void;
  updateRecipeNotes: (id: string, notes: string) => void;
  cookRecipeAction: (recipe: Recipe, servingsMultiplier?: number) => void;
  logRecipeMealAction: (recipe: Recipe, servingsMultiplier?: number, mealType?: MealLogEntry['mealType']) => void;

  // Cook mode
  activeCookModeRecipe: Recipe | null;
  setActiveCookModeRecipe: (recipe: Recipe | null) => void;

  // Grocery List
  groceryList: GroceryItem[];
  addGroceryItem: (item: Omit<GroceryItem, 'id'>) => void;
  toggleGroceryItem: (id: string) => void;
  deleteGroceryItem: (id: string) => void;
  clearCheckedGroceryItems: () => void;
  addMissingIngredientsToGrocery: (recipe: Recipe) => number;

  // Weight & History
  weightLogs: WeightEntry[];
  addWeightLog: (weightKg: number, date?: string) => void;
  deleteWeightLog: (id: string) => void;

  // Food waste impact
  foodWasteStats: FoodWasteStats;

  // Theme & Notifications
  darkMode: boolean;
  toggleDarkMode: () => void;
  notifications: AppNotification[];
  dismissNotification: (id: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(`pantrymacros_${key}`);
    return raw ? JSON.parse(raw) : fallback;
  } catch (err) {
    console.warn(`Failed to read ${key} from localStorage:`, err);
    return fallback;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(`pantrymacros_${key}`, JSON.stringify(value));
  } catch (err) {
    console.warn(`Failed to write ${key} to localStorage:`, err);
  }
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('pantrymacros_dark_mode');
    if (saved !== null) return saved === 'true';
    return true; // Default dark mode for sporty Whoop/MacroFactor aesthetic
  });

  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('pantrymacros_dark_mode', String(darkMode));
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode((prev) => !prev);

  // User Profile
  const [user, setUser] = useState<UserProfile>(() =>
    loadFromStorage('user_profile', DEFAULT_USER)
  );

  useEffect(() => {
    saveToStorage('user_profile', user);
  }, [user]);

  const updateUser = (updates: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...updates }));
  };

  const recomputeAutoTargets = () => {
    const suggested = calculateSuggestedMacros({
      age: user.age,
      sex: user.sex,
      heightCm: user.heightCm,
      weightKg: user.weightKg,
      activityLevel: user.activityLevel,
      goal: user.goal,
    });
    setUser((prev) => ({ ...prev, targets: suggested }));
  };

  // Selected date
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());

  const goToPreviousDay = () => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    date.setDate(date.getDate() - 1);
    const yr = date.getFullYear();
    const mo = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    setSelectedDate(`${yr}-${mo}-${day}`);
  };

  const goToNextDay = () => {
    const [y, m, d] = selectedDate.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    date.setDate(date.getDate() + 1);
    const yr = date.getFullYear();
    const mo = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    setSelectedDate(`${yr}-${mo}-${day}`);
  };

  const goToToday = () => {
    setSelectedDate(getTodayDateString());
  };

  // Pantry
  const [pantry, setPantry] = useState<PantryItem[]>(() =>
    loadFromStorage('pantry_items', INITIAL_PANTRY)
  );

  useEffect(() => {
    saveToStorage('pantry_items', pantry);
  }, [pantry]);

  const addPantryItem = (item: Omit<PantryItem, 'id' | 'addedDate'>) => {
    const newItem: PantryItem = {
      ...item,
      id: 'pantry_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
      addedDate: new Date().toISOString(),
    };
    setPantry((prev) => [newItem, ...prev]);
  };

  const updatePantryItem = (id: string, updates: Partial<PantryItem>) => {
    setPantry((prev) => prev.map((item) => (item.id === id ? { ...item, ...updates } : item)));
  };

  const deletePantryItem = (id: string) => {
    setPantry((prev) => prev.filter((item) => item.id !== id));
  };

  const bulkAddPantryItems = (items: Array<Omit<PantryItem, 'id' | 'addedDate'>>) => {
    const newItems: PantryItem[] = items.map((item, idx) => ({
      ...item,
      id: 'pantry_' + Date.now() + '_' + idx,
      addedDate: new Date().toISOString(),
    }));
    setPantry((prev) => [...newItems, ...prev]);
  };

  // Food waste tracking stats
  const [foodWasteStats, setFoodWasteStats] = useState<FoodWasteStats>(() =>
    loadFromStorage('food_waste_stats', {
      itemsSavedCount: 14,
      estimatedMoneySaved: 58.5,
      estimatedKgSaved: 6.2,
    })
  );

  useEffect(() => {
    saveToStorage('food_waste_stats', foodWasteStats);
  }, [foodWasteStats]);

  const decrementPantryForRecipe = (recipe: Recipe, servingsMultiplier = 1): number => {
    let savedUrgentCount = 0;
    let totalKgSavedEstimate = 0;

    setPantry((prevPantry) => {
      const nextPantry = [...prevPantry];

      for (const ingredient of recipe.ingredients) {
        if (!ingredient.fromPantry) continue;
        const normIngName = ingredient.name.toLowerCase().trim();

        const matchIdx = nextPantry.findIndex((p) => {
          const normPantryName = p.name.toLowerCase().trim();
          return normPantryName.includes(normIngName) || normIngName.includes(normPantryName);
        });

        if (matchIdx !== -1) {
          const item = nextPantry[matchIdx];
          const reqAmount = ingredient.quantity * (servingsMultiplier / (recipe.servings || 1));
          const urgency = getUrgencyStatus(getDaysUntilExpiration(item.expirationDate));

          if (urgency === 'use_soon' || urgency === 'expired') {
            savedUrgentCount += 1;
            totalKgSavedEstimate += Math.min(0.5, (reqAmount || 150) / 1000);
          }

          if (item.quantity > reqAmount) {
            nextPantry[matchIdx] = {
              ...item,
              quantity: Math.max(0, Math.round((item.quantity - reqAmount) * 10) / 10),
            };
          } else {
            // Used up item completely
            nextPantry.splice(matchIdx, 1);
          }
        }
      }

      return nextPantry;
    });

    if (savedUrgentCount > 0) {
      setFoodWasteStats((prev) => ({
        itemsSavedCount: prev.itemsSavedCount + savedUrgentCount,
        estimatedMoneySaved: prev.estimatedMoneySaved + savedUrgentCount * 4.5,
        estimatedKgSaved: Math.round((prev.estimatedKgSaved + totalKgSavedEstimate) * 10) / 10,
      }));
    }

    return savedUrgentCount;
  };

  // Meals
  const [meals, setMeals] = useState<MealLogEntry[]>(() =>
    loadFromStorage('meal_logs', INITIAL_MEALS)
  );

  useEffect(() => {
    saveToStorage('meal_logs', meals);
  }, [meals]);

  const addMeal = (entry: Omit<MealLogEntry, 'id' | 'timestamp'>) => {
    const newMeal: MealLogEntry = {
      ...entry,
      id: 'meal_' + Date.now(),
      timestamp: new Date().toISOString(),
    };
    setMeals((prev) => [newMeal, ...prev]);
  };

  const updateMeal = (id: string, updates: Partial<MealLogEntry>) => {
    setMeals((prev) => prev.map((m) => (m.id === id ? { ...m, ...updates } : m)));
  };

  const deleteMeal = (id: string) => {
    setMeals((prev) => prev.filter((m) => m.id !== id));
  };

  // Today's logged macros & metrics
  const todayLogged = useMemo(() => {
    const dayMeals = meals.filter((m) => m.date === selectedDate);
    return dayMeals.reduce(
      (acc, m) => ({
        calories: acc.calories + m.calories,
        protein: acc.protein + m.protein,
        carbs: acc.carbs + m.carbs,
        fat: acc.fat + m.fat,
      }),
      { calories: 0, protein: 0, carbs: 0, fat: 0 }
    );
  }, [meals, selectedDate]);

  const remainingMacros = useMemo(() => {
    return {
      calories: Math.max(0, user.targets.calories - todayLogged.calories),
      protein: Math.max(0, user.targets.protein - todayLogged.protein),
      carbs: Math.max(0, user.targets.carbs - todayLogged.carbs),
      fat: Math.max(0, user.targets.fat - todayLogged.fat),
    };
  }, [user.targets, todayLogged]);

  const overUnderMacros = useMemo(() => {
    return {
      calories: user.targets.calories - todayLogged.calories,
      protein: user.targets.protein - todayLogged.protein,
      carbs: user.targets.carbs - todayLogged.carbs,
      fat: user.targets.fat - todayLogged.fat,
    };
  }, [user.targets, todayLogged]);

  // Streak counter (days with at least 1 logged meal ending on or before today)
  const streakCount = useMemo(() => {
    const loggedDates = new Set(meals.map((m) => m.date));
    let count = 0;
    const checkDate = new Date();

    while (true) {
      const yr = checkDate.getFullYear();
      const mo = String(checkDate.getMonth() + 1).padStart(2, '0');
      const dy = String(checkDate.getDate()).padStart(2, '0');
      const dateStr = `${yr}-${mo}-${dy}`;

      if (loggedDates.has(dateStr)) {
        count++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        // If today has no logs yet, check if yesterday had logs
        if (count === 0) {
          checkDate.setDate(checkDate.getDate() - 1);
          const yYr = checkDate.getFullYear();
          const yMo = String(checkDate.getMonth() + 1).padStart(2, '0');
          const yDy = String(checkDate.getDate()).padStart(2, '0');
          if (loggedDates.has(`${yYr}-${yMo}-${yDy}`)) {
            // Count from yesterday
            count++;
            checkDate.setDate(checkDate.getDate() - 1);
            continue;
          }
        }
        break;
      }
    }
    return Math.max(count, 1);
  }, [meals]);

  // Recipes
  const [recipes, setRecipes] = useState<Recipe[]>(() =>
    loadFromStorage('saved_recipes', INITIAL_RECIPES)
  );

  useEffect(() => {
    saveToStorage('saved_recipes', recipes);
  }, [recipes]);

  const saveRecipe = (recipe: Recipe) => {
    setRecipes((prev) => {
      const idx = prev.findIndex((r) => r.id === recipe.id);
      if (idx !== -1) {
        const copy = [...prev];
        copy[idx] = recipe;
        return copy;
      }
      return [recipe, ...prev];
    });
  };

  const toggleFavoriteRecipe = (id: string) => {
    setRecipes((prev) =>
      prev.map((r) => (r.id === id ? { ...r, favorited: !r.favorited } : r))
    );
  };

  const rateRecipe = (id: string, rating: number) => {
    setRecipes((prev) => prev.map((r) => (r.id === id ? { ...r, rating } : r)));
  };

  const updateRecipeNotes = (id: string, notes: string) => {
    setRecipes((prev) =>
      prev.map((r) => (r.id === id ? { ...r, personalNotes: notes } : r))
    );
  };

  const cookRecipeAction = (recipe: Recipe, servingsMultiplier = 1) => {
    // 1. Decrement pantry
    decrementPantryForRecipe(recipe, servingsMultiplier);

    // 2. Mark recipe last cooked date
    setRecipes((prev) =>
      prev.map((r) =>
        r.id === recipe.id ? { ...r, lastCookedDate: new Date().toISOString() } : r
      )
    );
  };

  const logRecipeMealAction = (
    recipe: Recipe,
    servingsMultiplier = 1,
    mealType: MealLogEntry['mealType'] = 'dinner'
  ) => {
    const scale = servingsMultiplier;
    addMeal({
      date: selectedDate,
      title: recipe.title,
      mealType,
      calories: Math.round(recipe.macrosPerServing.calories * scale),
      protein: Math.round(recipe.macrosPerServing.protein * scale),
      carbs: Math.round(recipe.macrosPerServing.carbs * scale),
      fat: Math.round(recipe.macrosPerServing.fat * scale),
      quantity: `${scale} serving(s)`,
      recipeId: recipe.id,
    });
  };

  // Cook Mode Active Recipe
  const [activeCookModeRecipe, setActiveCookModeRecipe] = useState<Recipe | null>(null);

  // Grocery List
  const [groceryList, setGroceryList] = useState<GroceryItem[]>(() =>
    loadFromStorage('grocery_list', INITIAL_GROCERY)
  );

  useEffect(() => {
    saveToStorage('grocery_list', groceryList);
  }, [groceryList]);

  const addGroceryItem = (item: Omit<GroceryItem, 'id'>) => {
    const newItem: GroceryItem = {
      ...item,
      id: 'groc_' + Date.now() + '_' + Math.random().toString(36).substring(2, 5),
    };
    setGroceryList((prev) => [newItem, ...prev]);
  };

  const toggleGroceryItem = (id: string) => {
    setGroceryList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item))
    );
  };

  const deleteGroceryItem = (id: string) => {
    setGroceryList((prev) => prev.filter((item) => item.id !== id));
  };

  const clearCheckedGroceryItems = () => {
    setGroceryList((prev) => prev.filter((item) => !item.checked));
  };

  const addMissingIngredientsToGrocery = (recipe: Recipe): number => {
    const missing = recipe.ingredients.filter((i) => !i.fromPantry);
    if (missing.length === 0) return 0;

    setGroceryList((prev) => {
      const added: GroceryItem[] = missing.map((item, idx) => ({
        id: 'groc_' + Date.now() + '_' + idx,
        name: item.name,
        quantity: item.quantity,
        unit: item.unit,
        checked: false,
        recipeSource: recipe.title,
        category: 'Missing Recipe Items',
      }));
      return [...added, ...prev];
    });

    return missing.length;
  };

  // Weight Tracking
  const [weightLogs, setWeightLogs] = useState<WeightEntry[]>(() =>
    loadFromStorage('weight_logs', INITIAL_WEIGHT_LOGS)
  );

  useEffect(() => {
    saveToStorage('weight_logs', weightLogs);
  }, [weightLogs]);

  const addWeightLog = (weightKg: number, date = selectedDate) => {
    const newEntry: WeightEntry = {
      id: 'w_' + Date.now(),
      date,
      weightKg,
    };
    setWeightLogs((prev) => {
      const filtered = prev.filter((e) => e.date !== date);
      return [...filtered, newEntry].sort((a, b) => a.date.localeCompare(b.date));
    });
    // Also update current profile weight
    setUser((prev) => ({ ...prev, weightKg }));
  };

  const deleteWeightLog = (id: string) => {
    setWeightLogs((prev) => prev.filter((w) => w.id !== id));
  };

  // Notifications
  const [dismissedNotifications, setDismissedNotifications] = useState<string[]>(() =>
    loadFromStorage('dismissed_notifications', [])
  );

  const notifications = useMemo<AppNotification[]>(() => {
    const list: AppNotification[] = [];

    // Check expiring items in pantry (<= 2 days)
    const urgentItems = pantry.filter((p) => {
      const days = getDaysUntilExpiration(p.expirationDate);
      return days >= 0 && days <= 2;
    });

    if (urgentItems.length > 0) {
      const itemNames = urgentItems.slice(0, 2).map((i) => i.name).join(' & ');
      const notifId = 'notif_exp_' + urgentItems.map((i) => i.id).join('_');
      if (!dismissedNotifications.includes(notifId)) {
        list.push({
          id: notifId,
          type: 'urgency',
          message: `${itemNames} will expire soon! Generate recipes to use them now.`,
          timestamp: new Date().toISOString(),
          actionText: 'Find Recipes',
          actionRoute: 'recipes',
        });
      }
    }

    // Remind to log dinner if past 18:00 and dinner isn't logged today
    const currentHour = new Date().getHours();
    const hasDinner = meals.some(
      (m) => m.date === getTodayDateString() && (m.mealType === 'dinner' || m.calories > 300)
    );
    if (currentHour >= 18 && !hasDinner) {
      const dinnerNotifId = 'notif_dinner_' + getTodayDateString();
      if (!dismissedNotifications.includes(dinnerNotifId)) {
        list.push({
          id: dinnerNotifId,
          type: 'reminder',
          message: 'Evening check-in: Remember to log your dinner to maintain your streak!',
          timestamp: new Date().toISOString(),
          actionText: 'Log Meal',
          actionRoute: 'dashboard',
        });
      }
    }

    return list;
  }, [pantry, meals, dismissedNotifications]);

  const dismissNotification = (id: string) => {
    setDismissedNotifications((prev) => {
      const updated = [...prev, id];
      saveToStorage('dismissed_notifications', updated);
      return updated;
    });
  };

  return (
    <AppContext.Provider
      value={{
        user,
        updateUser,
        recomputeAutoTargets,
        selectedDate,
        setSelectedDate,
        goToPreviousDay,
        goToNextDay,
        goToToday,
        todayLogged,
        remainingMacros,
        overUnderMacros,
        streakCount,
        meals,
        addMeal,
        updateMeal,
        deleteMeal,
        pantry,
        addPantryItem,
        updatePantryItem,
        deletePantryItem,
        bulkAddPantryItems,
        decrementPantryForRecipe,
        recipes,
        saveRecipe,
        toggleFavoriteRecipe,
        rateRecipe,
        updateRecipeNotes,
        cookRecipeAction,
        logRecipeMealAction,
        activeCookModeRecipe,
        setActiveCookModeRecipe,
        groceryList,
        addGroceryItem,
        toggleGroceryItem,
        deleteGroceryItem,
        clearCheckedGroceryItems,
        addMissingIngredientsToGrocery,
        weightLogs,
        addWeightLog,
        deleteWeightLog,
        foodWasteStats,
        darkMode,
        toggleDarkMode,
        notifications,
        dismissNotification,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
