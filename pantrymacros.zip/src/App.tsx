import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar, NavTab } from './components/Navigation/Sidebar';
import { DashboardView } from './components/Dashboard/DashboardView';
import { PantryInventory } from './components/Pantry/PantryInventory';
import { RecipeEngineView } from './components/Recipes/RecipeEngineView';
import { GroceryListView } from './components/Grocery/GroceryListView';
import { HistoryView } from './components/History/HistoryView';
import { SettingsView } from './components/Settings/SettingsView';
import { PantryScannerModal } from './components/Pantry/PantryScannerModal';
import { OnboardingModal } from './components/Onboarding/OnboardingModal';
import { Menu, X } from 'lucide-react';

const MainContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen flex bg-[#FAFAF7] dark:bg-[#14181C] text-[#1E2329] dark:text-[#EAECEF] font-sans">
      {/* Persistent Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onOpenScanner={() => setIsScannerOpen(true)}
        />
      </div>

      {/* Mobile / Tablet Drawer Sidebar Fallback */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/60 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative w-72 max-w-[85vw] h-full bg-white dark:bg-[#111417] z-10 shadow-2xl flex flex-col justify-between">
            <Sidebar
              activeTab={activeTab}
              setActiveTab={(tab) => {
                setActiveTab(tab);
                setMobileMenuOpen(false);
              }}
              onOpenScanner={() => {
                setIsScannerOpen(true);
                setMobileMenuOpen(false);
              }}
            />
          </div>
        </div>
      )}

      {/* Main View Area (Desktop Optimized Baseline >= 1280px) */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile Header Bar */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-white dark:bg-[#111417] border-b border-[#E2E4E8] dark:border-[#22272E] sticky top-0 z-30">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-1.5 rounded-lg text-[#57606A] dark:text-[#8B949E] hover:bg-slate-100 dark:hover:bg-[#22272E]"
              aria-label="Open menu"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="font-bold text-sm tracking-tight text-[#14181C] dark:text-white flex items-center gap-1.5">
              <span>PantryMacros</span>
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#A6243D]" />
                <span className="w-1.5 h-1.5 rounded-full bg-[#D4A017]" />
                <span className="w-1.5 h-1.5 rounded-full bg-[#3E7C6B]" />
              </span>
            </div>
          </div>

          <button
            onClick={() => setIsScannerOpen(true)}
            className="text-xs px-2.5 py-1 rounded-lg bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] font-semibold"
          >
            Scan
          </button>
        </header>

        {/* Content View Container */}
        <main className="flex-1 p-6 md:p-8 lg:p-10 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <DashboardView
              onNavigateTab={(tab) => setActiveTab(tab)}
              onOpenScanner={() => setIsScannerOpen(true)}
            />
          )}

          {activeTab === 'pantry' && (
            <PantryInventory
              onOpenScanner={() => setIsScannerOpen(true)}
              onNavigateToRecipes={() => setActiveTab('recipes')}
            />
          )}

          {activeTab === 'recipes' && (
            <RecipeEngineView onOpenScanner={() => setIsScannerOpen(true)} />
          )}

          {activeTab === 'grocery' && <GroceryListView />}

          {activeTab === 'history' && <HistoryView />}

          {activeTab === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* AI Pantry Vision Scanner Modal */}
      <PantryScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScanCompleteNavigateToRecipes={() => setActiveTab('recipes')}
      />

      {/* First-use Onboarding Modal */}
      <OnboardingModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
