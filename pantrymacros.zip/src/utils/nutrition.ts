import { ActivityLevel, FitnessGoal, MacroBudget, UrgencyStatus } from '../types';

export function calculateSuggestedMacros(params: {
  age: number;
  sex: 'male' | 'female' | 'other';
  heightCm: number;
  weightKg: number;
  activityLevel: ActivityLevel;
  goal: FitnessGoal;
}): MacroBudget {
  const { age, sex, heightCm, weightKg, activityLevel, goal } = params;

  // Mifflin-St Jeor BMR
  let bmr: number;
  if (sex === 'male') {
    bmr = 10 * weightKg + 6.25 * heightCm - 5 * age + 5;
  } else if (sex === 'female') {
    bmr = 10 * weightKg + 6.25 * heightCm - 5 * age - 161;
  } else {
    bmr = 10 * weightKg + 6.25 * heightCm - 5 * age - 78;
  }

  // Activity multipliers
  const activityMultipliers: Record<ActivityLevel, number> = {
    sedentary: 1.2,
    lightly_active: 1.375,
    moderately_active: 1.55,
    very_active: 1.725,
    extra_active: 1.9,
  };

  const tdee = bmr * (activityMultipliers[activityLevel] || 1.375);

  let targetCalories = tdee;
  if (goal === 'lose_fat') {
    targetCalories = Math.max(1200, tdee - 450);
  } else if (goal === 'build_muscle') {
    targetCalories = tdee + 300;
  }

  // Protein targets based on lean mass / body weight
  let proteinPerKg = 2.0;
  if (goal === 'lose_fat') proteinPerKg = 2.2;
  if (goal === 'build_muscle') proteinPerKg = 2.2;

  const targetProteinGrams = Math.round(weightKg * proteinPerKg);
  const proteinCalories = targetProteinGrams * 4;

  // Fat target ~27% of total calories
  const fatCalories = targetCalories * 0.27;
  const targetFatGrams = Math.round(fatCalories / 9);

  // Remainder to carbohydrates
  const remainingCaloriesForCarbs = Math.max(0, targetCalories - (proteinCalories + fatCalories));
  const targetCarbsGrams = Math.round(remainingCaloriesForCarbs / 4);

  return {
    calories: Math.round(targetCalories),
    protein: targetProteinGrams,
    carbs: targetCarbsGrams,
    fat: targetFatGrams,
  };
}

export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatDatePretty(dateStr: string): string {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

export function getDaysUntilExpiration(expirationDateStr: string): number {
  if (!expirationDateStr) return 999;
  const exp = new Date(expirationDateStr).getTime();
  const now = new Date().setHours(0, 0, 0, 0);
  const diffDays = Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
  return diffDays;
}

export function getUrgencyStatus(daysUntil: number): UrgencyStatus {
  if (daysUntil < 0) return 'expired';
  if (daysUntil <= 3) return 'use_soon';
  return 'fresh';
}

export function addDaysToDate(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString();
}
