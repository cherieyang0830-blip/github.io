import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  Trash2,
  Edit2,
  Calendar,
  UtensilsCrossed,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatDatePretty, getTodayDateString } from '../../utils/nutrition';
import { MealLogEntry } from '../../types';
import { QuickMealLogModal } from './QuickMealLogModal';

export const TodayMealLogs: React.FC = () => {
  const {
    selectedDate,
    setSelectedDate,
    goToPreviousDay,
    goToNextDay,
    goToToday,
    meals,
    deleteMeal,
    todayLogged,
    user,
  } = useApp();

  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [editingMeal, setEditingMeal] = useState<MealLogEntry | null>(null);

  const dayMeals = meals.filter((m) => m.date === selectedDate);
  const isToday = selectedDate === getTodayDateString();

  const handleEdit = (meal: MealLogEntry) => {
    setEditingMeal(meal);
    setIsLogModalOpen(true);
  };

  const handleOpenNew = () => {
    setEditingMeal(null);
    setIsLogModalOpen(true);
  };

  // Group meals by category
  const categories: Array<MealLogEntry['mealType']> = ['breakfast', 'lunch', 'dinner', 'snack'];

  return (
    <div className="space-y-4">
      {/* Day Browser Navigation Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#E2E4E8] dark:border-[#22272E]">
        <div className="flex items-center gap-2">
          <div className="flex items-center rounded-lg border border-[#E2E4E8] dark:border-[#30363D] bg-white dark:bg-[#161B22] p-0.5">
            <button
              onClick={goToPreviousDay}
              className="p-1.5 rounded-md hover:bg-[#F2F4F7] dark:hover:bg-[#21262D] text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white transition-colors cursor-pointer"
              title="Previous Day"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <span className="px-3 text-xs font-semibold text-[#14181C] dark:text-white flex items-center gap-1.5 min-w-[130px] justify-center">
              <Calendar className="w-3.5 h-3.5 text-[#6E7781]" />
              {formatDatePretty(selectedDate)}
            </span>

            <button
              onClick={goToNextDay}
              className="p-1.5 rounded-md hover:bg-[#F2F4F7] dark:hover:bg-[#21262D] text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white transition-colors cursor-pointer"
              title="Next Day"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {!isToday && (
            <button
              onClick={goToToday}
              className="px-2.5 py-1 text-xs font-medium rounded-lg text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white hover:bg-slate-200 dark:hover:bg-[#22272E] transition-colors cursor-pointer"
            >
              Back to today
            </button>
          )}
        </div>

        {/* Action: Log Food */}
        <button
          onClick={handleOpenNew}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-[#EAECEF] text-white dark:text-[#14181C] text-xs font-semibold transition-colors cursor-pointer shadow-xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Log Food</span>
        </button>
      </div>

      {/* Meals List */}
      {dayMeals.length === 0 ? (
        <div className="py-12 px-4 rounded-xl border border-dashed border-[#E2E4E8] dark:border-[#22272E] text-center">
          <UtensilsCrossed className="w-8 h-8 mx-auto text-[#6E7781] dark:text-[#768390] mb-2 stroke-[1.5]" />
          <h3 className="text-sm font-semibold text-[#14181C] dark:text-white mb-1">
            No meals logged for this day
          </h3>
          <p className="text-xs text-[#6E7781] dark:text-[#8B949E] max-w-sm mx-auto mb-4">
            Track your meals or cook a suggested recipe to keep your macros dialed in.
          </p>
          <button
            onClick={handleOpenNew}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] text-xs font-semibold hover:opacity-90 transition-opacity cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            Log Meal Entry
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {categories.map((category) => {
            const catMeals = dayMeals.filter((m) => m.mealType === category);
            if (catMeals.length === 0) return null;

            const catCalories = catMeals.reduce((sum, m) => sum + m.calories, 0);

            return (
              <div key={category} className="space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold text-[#57606A] dark:text-[#8B949E] px-1 capitalize">
                  <span>{category}</span>
                  <span className="tabular-nums font-medium text-[11px]">
                    {catCalories} kcal
                  </span>
                </div>

                <div className="space-y-1.5">
                  {catMeals.map((meal) => (
                    <div
                      key={meal.id}
                      className="group flex items-center justify-between p-3 rounded-xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] hover:border-[#14181C]/30 dark:hover:border-white/30 transition-colors"
                    >
                      <div className="min-w-0 pr-3">
                        <div className="text-xs font-semibold text-[#14181C] dark:text-white truncate">
                          {meal.title}
                        </div>
                        {meal.quantity && (
                          <div className="text-[11px] text-[#6E7781] dark:text-[#8B949E] truncate">
                            {meal.quantity}
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-4 shrink-0">
                        {/* Macro details */}
                        <div className="flex items-center gap-3 text-right">
                          <div className="text-right">
                            <span className="tabular-nums text-xs font-bold text-[#14181C] dark:text-white block">
                              {meal.calories}
                            </span>
                            <span className="text-[10px] text-[#6E7781] dark:text-[#8B949E]">kcal</span>
                          </div>

                          <div className="hidden sm:flex items-center gap-2 text-[11px] font-semibold tabular-nums border-l border-[#EAECEF] dark:border-[#21262D] pl-3">
                            <span className="text-[#A6243D] dark:text-rose-400" title="Protein">
                              {meal.protein}g P
                            </span>
                            <span className="text-[#D4A017] dark:text-amber-400" title="Carbohydrates">
                              {meal.carbs}g C
                            </span>
                            <span className="text-[#3E7C6B] dark:text-teal-400" title="Fat">
                              {meal.fat}g F
                            </span>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1 opacity-80 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                          <button
                            onClick={() => handleEdit(meal)}
                            className="p-1 rounded-md text-[#6E7781] hover:text-[#14181C] dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#22272E] transition-colors"
                            title="Edit entry"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => deleteMeal(meal.id)}
                            className="p-1 rounded-md text-[#6E7781] hover:text-[#A6243D] hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                            title="Delete entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit or Create Meal Modal */}
      {isLogModalOpen && (
        <QuickMealLogModal
          isOpen={isLogModalOpen}
          onClose={() => {
            setIsLogModalOpen(false);
            setEditingMeal(null);
          }}
          editMeal={editingMeal}
        />
      )}
    </div>
  );
};
