import React, { useMemo } from 'react';
import {
  Sparkles,
  Utensils,
  Clock,
  Flame,
  AlertTriangle,
  ChevronRight,
  Plus,
  Scale,
  Leaf,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MacroProgressRings } from './MacroProgressRings';
import { TodayMealLogs } from './TodayMealLogs';
import { getDaysUntilExpiration, getUrgencyStatus } from '../../utils/nutrition';
import { NavTab } from '../Navigation/Sidebar';

interface DashboardViewProps {
  onNavigateTab: (tab: NavTab) => void;
  onOpenScanner: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigateTab,
  onOpenScanner,
}) => {
  const {
    user,
    todayLogged,
    overUnderMacros,
    pantry,
    streakCount,
    foodWasteStats,
    notifications,
    dismissNotification,
  } = useApp();

  // Urgent pantry items (daysLeft <= 3)
  const urgentPantryItems = useMemo(() => {
    return pantry
      .map((item) => {
        const days = getDaysUntilExpiration(item.expirationDate);
        const urgency = getUrgencyStatus(days);
        return { ...item, daysLeft: days, urgency };
      })
      .filter((i) => i.urgency === 'use_soon' || i.urgency === 'expired')
      .sort((a, b) => a.daysLeft - b.daysLeft);
  }, [pantry]);

  // Calorie compliance assessment
  const calDifference = overUnderMacros.calories; // targets - todayLogged
  const isTargetAchieved = Math.abs(calDifference) <= 100;
  const isOverTarget = calDifference < -100;

  return (
    <div className="space-y-8">
      {/* Top Welcome & Notification Banners */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-[#14181C] dark:text-white">
              Daily Nutrition Dashboard
            </h1>
            <p className="text-xs text-[#6E7781] dark:text-[#8B949E] mt-0.5">
              Welcome back, {user.name}. Precision daily fuel synchronized with your home pantry.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenScanner}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-bold transition-colors cursor-pointer shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
              <span>Scan Fridge / Shelf</span>
            </button>
          </div>
        </div>

        {/* Active In-App Notifications Banner */}
        {notifications.length > 0 && (
          <div className="space-y-2">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                className="flex items-center justify-between p-3 rounded-xl border border-[#D4A017]/30 bg-[#D4A017]/5 dark:bg-[#D4A017]/10 text-xs text-[#14181C] dark:text-white"
              >
                <div className="flex items-center gap-2.5">
                  <Clock className="w-4 h-4 text-[#D4A017] shrink-0" />
                  <span>{notif.message}</span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {notif.actionText && (
                    <button
                      onClick={() => {
                        dismissNotification(notif.id);
                        if (notif.actionRoute) onNavigateTab(notif.actionRoute as NavTab);
                      }}
                      className="text-xs font-bold text-[#14181C] dark:text-white underline hover:opacity-80 cursor-pointer"
                    >
                      {notif.actionText}
                    </button>
                  )}
                  <button
                    onClick={() => dismissNotification(notif.id)}
                    className="text-[#6E7781] hover:text-[#14181C] dark:hover:text-white px-1 text-sm font-bold cursor-pointer"
                  >
                    ×
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Hero Macro Visualizer: Rings Integrated Directly into Dashboard, Not Boxed */}
      <div className="pt-2 pb-4">
        <MacroProgressRings />
      </div>

      {/* MULTI-COLUMN DESKTOP LAYOUT (1280px+ wide) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column (7 cols): Today's Food Log & Day Navigator */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-base font-bold text-[#14181C] dark:text-white">
                  Today&apos;s Meals & Log
                </h2>
                <p className="text-xs text-[#6E7781] dark:text-[#8B949E]">
                  Browse meals, log manual items, or check macro totals.
                </p>
              </div>

              {/* End of day target status summary */}
              <div className="text-right">
                <div
                  className={`text-xs font-bold tabular-nums ${
                    isTargetAchieved
                      ? 'text-emerald-600 dark:text-emerald-400'
                      : isOverTarget
                      ? 'text-[#A6243D] dark:text-rose-400'
                      : 'text-[#D4A017] dark:text-amber-400'
                  }`}
                >
                  {isTargetAchieved
                    ? 'Target Dialed In'
                    : isOverTarget
                    ? `${Math.abs(calDifference)} kcal over`
                    : `${calDifference} kcal to go`}
                </div>
                <div className="text-[10px] text-[#6E7781] dark:text-[#8B949E]">
                  {todayLogged.calories} / {user.targets.calories} kcal
                </div>
              </div>
            </div>

            <TodayMealLogs />
          </div>
        </div>

        {/* Right Column (5 cols): Pantry Urgency Radar & Quick Recipe Actions */}
        <div className="lg:col-span-5 space-y-6">
          {/* Pantry Freshness & Urgency Radar Module */}
          <div className="p-6 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#D4A017]" />
                <h2 className="text-base font-bold text-[#14181C] dark:text-white">
                  Pantry Urgency Radar
                </h2>
              </div>
              <button
                onClick={() => onNavigateTab('pantry')}
                className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white flex items-center cursor-pointer"
              >
                <span>View All ({pantry.length})</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {urgentPantryItems.length === 0 ? (
              <div className="p-6 rounded-xl bg-[#F6F8FA] dark:bg-[#0D1117] text-center space-y-2">
                <CheckCircle2 className="w-6 h-6 text-[#3E7C6B] mx-auto" />
                <div className="text-xs font-semibold text-[#14181C] dark:text-white">
                  Zero Urgent Expirations
                </div>
                <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                  All current pantry items have plenty of shelf life remaining.
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                  Items expiring soonest: prioritize these in your next meal!
                </div>
                <div className="divide-y divide-[#EAECEF] dark:divide-[#21262D] border border-[#E2E4E8] dark:border-[#22272E] rounded-xl overflow-hidden">
                  {urgentPantryItems.slice(0, 5).map((item) => (
                    <div
                      key={item.id}
                      className="p-3 flex items-center justify-between bg-white dark:bg-[#161B22] hover:bg-[#F6F8FA] dark:hover:bg-[#1C2128] transition-colors"
                    >
                      <div>
                        <div className="text-xs font-semibold text-[#14181C] dark:text-white">
                          {item.name}
                        </div>
                        <div className="text-[10px] text-[#6E7781] dark:text-[#8B949E] capitalize">
                          {item.location} · {item.quantity} {item.unit}
                        </div>
                      </div>

                      <div className="text-right">
                        <span
                          className={`text-xs font-bold tabular-nums ${
                            item.urgency === 'expired'
                              ? 'text-[#A6243D] dark:text-rose-400'
                              : 'text-[#D4A017] dark:text-amber-400'
                          }`}
                        >
                          {item.daysLeft < 0
                            ? 'Expired'
                            : item.daysLeft === 0
                            ? 'Expires today'
                            : `${item.daysLeft}d left`}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => onNavigateTab('recipes')}
                  className="w-full flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-bold transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
                  <span>Generate Recipes with These Items</span>
                </button>
              </div>
            )}
          </div>

          {/* Quick Metrics & Food Waste Savings Card */}
          <div className="p-6 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] shadow-xs space-y-3">
            <div className="flex items-center gap-2">
              <Leaf className="w-4 h-4 text-[#3E7C6B]" />
              <h2 className="text-base font-bold text-[#14181C] dark:text-white">
                Eco & Wallet Protection
              </h2>
            </div>
            <p className="text-xs text-[#6E7781] dark:text-[#8B949E]">
              Tracked by cooking items before they expire:
            </p>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div className="p-3 rounded-xl bg-[#3E7C6B]/10 dark:bg-[#3E7C6B]/15">
                <span className="text-[10px] uppercase font-bold text-[#3E7C6B] dark:text-teal-400 block">
                  Est. Money Saved
                </span>
                <span className="text-xl font-extrabold tabular-nums text-[#14181C] dark:text-white">
                  ${foodWasteStats.estimatedMoneySaved.toFixed(0)}
                </span>
              </div>

              <div className="p-3 rounded-xl bg-[#3E7C6B]/10 dark:bg-[#3E7C6B]/15">
                <span className="text-[10px] uppercase font-bold text-[#3E7C6B] dark:text-teal-400 block">
                  Food Diverted
                </span>
                <span className="text-xl font-extrabold tabular-nums text-[#14181C] dark:text-white">
                  {foodWasteStats.estimatedKgSaved} kg
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
