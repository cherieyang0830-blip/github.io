import React, { useState } from 'react';
import { X, Plus, Search, Utensils } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { MealLogEntry } from '../../types';

interface QuickMealLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  editMeal?: MealLogEntry | null;
}

const COMMON_PRESETS = [
  { title: 'Chicken Breast (Cooked)', quantity: '200g', calories: 330, protein: 62, carbs: 0, fat: 7 },
  { title: 'Whole Eggs (3 Scrambled)', quantity: '3 large', calories: 215, protein: 18, carbs: 1.5, fat: 15 },
  { title: 'Whey Protein Shake', quantity: '1 scoop with water', calories: 130, protein: 26, carbs: 2, fat: 1.5 },
  { title: 'Greek Yogurt 0% Fat', quantity: '250g', calories: 145, protein: 25, carbs: 9, fat: 0 },
  { title: 'Rolled Oats with Water', quantity: '80g dry', calories: 300, protein: 11, carbs: 54, fat: 5 },
  { title: 'White Jasmine Rice (Cooked)', quantity: '200g', calories: 260, protein: 5, carbs: 57, fat: 0.6 },
  { title: 'Atlantic Salmon Fillet', quantity: '180g', calories: 370, protein: 36, carbs: 0, fat: 24 },
  { title: 'Medium Avocado', quantity: '1 whole (150g)', calories: 240, protein: 3, carbs: 12, fat: 22 },
];

export const QuickMealLogModal: React.FC<QuickMealLogModalProps> = ({
  isOpen,
  onClose,
  editMeal,
}) => {
  const { addMeal, updateMeal, selectedDate } = useApp();

  const [title, setTitle] = useState(editMeal ? editMeal.title : '');
  const [mealType, setMealType] = useState<MealLogEntry['mealType']>(
    editMeal ? editMeal.mealType : 'lunch'
  );
  const [quantity, setQuantity] = useState(editMeal?.quantity || '');
  const [calories, setCalories] = useState(editMeal ? String(editMeal.calories) : '');
  const [protein, setProtein] = useState(editMeal ? String(editMeal.protein) : '');
  const [carbs, setCarbs] = useState(editMeal ? String(editMeal.carbs) : '');
  const [fat, setFat] = useState(editMeal ? String(editMeal.fat) : '');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const handleSelectPreset = (preset: (typeof COMMON_PRESETS)[0]) => {
    setTitle(preset.title);
    setQuantity(preset.quantity);
    setCalories(String(preset.calories));
    setProtein(String(preset.protein));
    setCarbs(String(preset.carbs));
    setFat(String(preset.fat));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const parsedCal = parseFloat(calories) || 0;
    const parsedPro = parseFloat(protein) || 0;
    const parsedCarb = parseFloat(carbs) || 0;
    const parsedFat = parseFloat(fat) || 0;

    if (editMeal) {
      updateMeal(editMeal.id, {
        title: title.trim(),
        mealType,
        quantity: quantity.trim(),
        calories: Math.round(parsedCal),
        protein: Math.round(parsedPro),
        carbs: Math.round(parsedCarb),
        fat: Math.round(parsedFat),
      });
    } else {
      addMeal({
        date: selectedDate,
        title: title.trim(),
        mealType,
        quantity: quantity.trim(),
        calories: Math.round(parsedCal),
        protein: Math.round(parsedPro),
        carbs: Math.round(parsedCarb),
        fat: Math.round(parsedFat),
      });
    }

    onClose();
  };

  const filteredPresets = searchQuery
    ? COMMON_PRESETS.filter((p) => p.title.toLowerCase().includes(searchQuery.toLowerCase()))
    : COMMON_PRESETS;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-lg bg-white dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E] rounded-2xl shadow-xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#EAECEF] dark:border-[#21262D]">
          <div className="flex items-center gap-2">
            <Utensils className="w-4 h-4 text-[#A6243D]" />
            <h2 className="text-base font-bold text-[#14181C] dark:text-white">
              {editMeal ? 'Edit Meal Entry' : 'Log Food or Meal'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#6E7781] hover:text-[#14181C] dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#22272E] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Quick Presets Search */}
          {!editMeal && (
            <div className="space-y-2">
              <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E] block">
                Quick Preset Fill
              </label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#6E7781]" />
                <input
                  type="text"
                  placeholder="Filter common staples (chicken, oats, eggs, rice)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-[#F6F8FA] dark:bg-[#0D1117] text-[#14181C] dark:text-white placeholder-[#8B949E] focus:outline-hidden focus:border-[#14181C] dark:focus:border-white"
                />
              </div>

              <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pt-1">
                {filteredPresets.map((preset) => (
                  <button
                    key={preset.title}
                    type="button"
                    onClick={() => handleSelectPreset(preset)}
                    className="text-[11px] px-2.5 py-1 rounded-md bg-[#F2F4F7] hover:bg-slate-200 dark:bg-[#21262D] dark:hover:bg-[#30363D] text-[#14181C] dark:text-white transition-colors cursor-pointer truncate max-w-[200px]"
                  >
                    + {preset.title}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Meal Details Form */}
          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2 space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Food / Meal Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Sliced Turkey & Avocado Wrap"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden focus:border-[#14181C] dark:focus:border-white"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Category
              </label>
              <select
                value={mealType}
                onChange={(e) => setMealType(e.target.value as any)}
                className="w-full px-2.5 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden focus:border-[#14181C] dark:focus:border-white"
              >
                <option value="breakfast">Breakfast</option>
                <option value="lunch">Lunch</option>
                <option value="dinner">Dinner</option>
                <option value="snack">Snack</option>
              </select>
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
              Portion / Quantity (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g. 1 plate, 250 grams, 2 servings"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden focus:border-[#14181C] dark:focus:border-white"
            />
          </div>

          {/* Macro Inputs with Brand Colors */}
          <div className="pt-2">
            <div className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E] mb-2">
              Macro Breakdown
            </div>
            <div className="grid grid-cols-4 gap-2.5">
              {/* Calories */}
              <div className="p-2 rounded-lg border border-[#E2E4E8] dark:border-[#22272E] bg-[#F6F8FA] dark:bg-[#0D1117]">
                <label className="text-[10px] uppercase font-bold text-[#6E7781] block mb-1">
                  Calories
                </label>
                <input
                  type="number"
                  placeholder="0"
                  value={calories}
                  onChange={(e) => setCalories(e.target.value)}
                  className="w-full text-sm font-bold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
                />
                <span className="text-[10px] text-[#6E7781]">kcal</span>
              </div>

              {/* Protein */}
              <div className="p-2 rounded-lg border border-[#A6243D]/30 bg-[#A6243D]/5 dark:bg-[#A6243D]/10">
                <label className="text-[10px] uppercase font-bold text-[#A6243D] dark:text-rose-400 block mb-1">
                  Protein
                </label>
                <input
                  type="number"
                  placeholder="0"
                  value={protein}
                  onChange={(e) => setProtein(e.target.value)}
                  className="w-full text-sm font-bold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
                />
                <span className="text-[10px] text-[#A6243D] dark:text-rose-400 font-medium">grams</span>
              </div>

              {/* Carbs */}
              <div className="p-2 rounded-lg border border-[#D4A017]/30 bg-[#D4A017]/5 dark:bg-[#D4A017]/10">
                <label className="text-[10px] uppercase font-bold text-[#D4A017] dark:text-amber-400 block mb-1">
                  Carbs
                </label>
                <input
                  type="number"
                  placeholder="0"
                  value={carbs}
                  onChange={(e) => setCarbs(e.target.value)}
                  className="w-full text-sm font-bold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
                />
                <span className="text-[10px] text-[#D4A017] dark:text-amber-400 font-medium">grams</span>
              </div>

              {/* Fat */}
              <div className="p-2 rounded-lg border border-[#3E7C6B]/30 bg-[#3E7C6B]/5 dark:bg-[#3E7C6B]/10">
                <label className="text-[10px] uppercase font-bold text-[#3E7C6B] dark:text-teal-400 block mb-1">
                  Fat
                </label>
                <input
                  type="number"
                  placeholder="0"
                  value={fat}
                  onChange={(e) => setFat(e.target.value)}
                  className="w-full text-sm font-bold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
                />
                <span className="text-[10px] text-[#3E7C6B] dark:text-teal-400 font-medium">grams</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 pt-4 border-t border-[#EAECEF] dark:border-[#21262D]">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg text-[#57606A] dark:text-[#8B949E] hover:bg-slate-100 dark:hover:bg-[#22272E] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-semibold rounded-lg bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] transition-colors cursor-pointer"
            >
              {editMeal ? 'Save Changes' : 'Log Food'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
