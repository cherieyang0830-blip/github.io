import React, { useEffect, useState } from 'react';
import { useApp } from '../../context/AppContext';

export const MacroProgressRings: React.FC = () => {
  const { user, todayLogged, remainingMacros } = useApp();
  const [animated, setAnimated] = useState(false);

  // Trigger one deliberate ring filling animation on dashboard mount
  useEffect(() => {
    const timer = setTimeout(() => setAnimated(true), 60);
    return () => clearTimeout(timer);
  }, []);

  const targets = user.targets;

  // Percentage calculations (capped or uncapped for visual ring, up to 100% or overflow)
  const calPercent = Math.min(100, Math.round((todayLogged.calories / (targets.calories || 1)) * 100));
  const proPercent = Math.min(100, Math.round((todayLogged.protein / (targets.protein || 1)) * 100));
  const carbPercent = Math.min(100, Math.round((todayLogged.carbs / (targets.carbs || 1)) * 100));
  const fatPercent = Math.min(100, Math.round((todayLogged.fat / (targets.fat || 1)) * 100));

  // Concentric circle geometry
  // Center: 140, 140
  // Calories: r=115, circ = 2 * PI * 115 ≈ 722.56
  // Protein: r=92, circ = 2 * PI * 92 ≈ 578.05
  // Carbs: r=69, circ = 2 * PI * 69 ≈ 433.54
  // Fat: r=46, circ = 2 * PI * 46 ≈ 289.02
  const center = 140;
  const rings = [
    {
      id: 'calories',
      radius: 115,
      stroke: 10,
      color: '#607B96',
      bgTrack: 'rgba(96, 123, 150, 0.15)',
      percent: calPercent,
      circ: 2 * Math.PI * 115,
    },
    {
      id: 'protein',
      radius: 92,
      stroke: 10,
      color: '#A6243D', // deep raspberry
      bgTrack: 'rgba(166, 36, 61, 0.15)',
      percent: proPercent,
      circ: 2 * Math.PI * 92,
    },
    {
      id: 'carbs',
      radius: 69,
      stroke: 10,
      color: '#D4A017', // golden mustard
      bgTrack: 'rgba(212, 160, 23, 0.15)',
      percent: carbPercent,
      circ: 2 * Math.PI * 69,
    },
    {
      id: 'fat',
      radius: 46,
      stroke: 10,
      color: '#3E7C6B', // sage teal
      bgTrack: 'rgba(62, 124, 107, 0.15)',
      percent: fatPercent,
      circ: 2 * Math.PI * 46,
    },
  ];

  return (
    <div className="py-2 select-none">
      {/* Visual rings integrated seamlessly, not boxed in a standard template card */}
      <div className="flex flex-col lg:flex-row items-center gap-8 xl:gap-12">
        {/* Concentric Macro Progress SVG */}
        <div className="relative w-[280px] h-[280px] shrink-0 flex items-center justify-center">
          <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 280 280">
            {rings.map((ring) => {
              const strokeOffset = ring.circ - (ring.circ * (animated ? ring.percent : 0)) / 100;
              return (
                <g key={ring.id}>
                  {/* Background Track */}
                  <circle
                    cx={center}
                    cy={center}
                    r={ring.radius}
                    stroke={ring.bgTrack}
                    strokeWidth={ring.stroke}
                    fill="transparent"
                  />
                  {/* Active Animated Fill */}
                  <circle
                    cx={center}
                    cy={center}
                    r={ring.radius}
                    stroke={ring.color}
                    strokeWidth={ring.stroke}
                    strokeDasharray={ring.circ}
                    strokeDashoffset={strokeOffset}
                    strokeLinecap="round"
                    fill="transparent"
                    style={{
                      transition: 'stroke-dashoffset 1.1s cubic-bezier(0.16, 1, 0.3, 1)',
                    }}
                  />
                </g>
              );
            })}
          </svg>

          {/* Central Hero Data (Whoop / Levels inspired) */}
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
            <span className="text-[11px] font-medium tracking-wide uppercase text-[#6E7781] dark:text-[#8B949E]">
              Remaining
            </span>
            <div className="text-4xl font-extrabold tabular-nums tracking-tight text-[#14181C] dark:text-white mt-0.5">
              {remainingMacros.calories}
            </div>
            <span className="text-[12px] text-[#6E7781] dark:text-[#8B949E] font-medium">
              kcal today
            </span>
            <div className="mt-1 flex items-center gap-1.5 text-[10px] font-semibold text-[#57606A] dark:text-[#768390]">
              <span className="tabular-nums">{todayLogged.calories}</span>
              <span>/</span>
              <span className="tabular-nums">{targets.calories}</span>
            </div>
          </div>
        </div>

        {/* Macro Numbers Breakdown - Bold Tabular Numerals as Hero Content */}
        <div className="flex-1 w-full grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Protein */}
          <div className="relative p-4 rounded-xl border border-[#E2E4E8] dark:border-[#22272E] bg-white/70 dark:bg-[#161B22]/70 backdrop-blur-sm hover:border-[#A6243D]/50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#A6243D]" />
                <span className="text-xs font-semibold text-[#14181C] dark:text-white">
                  Protein
                </span>
              </div>
              <span className="text-[11px] font-semibold tabular-nums text-[#A6243D] dark:text-rose-400">
                {proPercent}%
              </span>
            </div>

            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-3xl font-extrabold tabular-nums tracking-tight text-[#14181C] dark:text-white">
                {remainingMacros.protein}
              </span>
              <span className="text-xs font-medium text-[#6E7781] dark:text-[#8B949E]">g left</span>
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] text-[#6E7781] dark:text-[#8B949E] pt-2 border-t border-[#EAECEF] dark:border-[#21262D]">
              <span>Logged: <strong className="tabular-nums font-semibold text-[#14181C] dark:text-white">{todayLogged.protein}g</strong></span>
              <span>Target: <strong className="tabular-nums font-semibold text-[#14181C] dark:text-white">{targets.protein}g</strong></span>
            </div>

            {/* Micro progress line */}
            <div className="w-full h-1 bg-[#A6243D]/15 rounded-full mt-2.5 overflow-hidden">
              <div
                className="h-full bg-[#A6243D] rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${Math.min(100, proPercent)}%` }}
              />
            </div>
          </div>

          {/* Carbohydrates */}
          <div className="relative p-4 rounded-xl border border-[#E2E4E8] dark:border-[#22272E] bg-white/70 dark:bg-[#161B22]/70 backdrop-blur-sm hover:border-[#D4A017]/50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#D4A017]" />
                <span className="text-xs font-semibold text-[#14181C] dark:text-white">
                  Carbs
                </span>
              </div>
              <span className="text-[11px] font-semibold tabular-nums text-[#D4A017] dark:text-amber-400">
                {carbPercent}%
              </span>
            </div>

            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-3xl font-extrabold tabular-nums tracking-tight text-[#14181C] dark:text-white">
                {remainingMacros.carbs}
              </span>
              <span className="text-xs font-medium text-[#6E7781] dark:text-[#8B949E]">g left</span>
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] text-[#6E7781] dark:text-[#8B949E] pt-2 border-t border-[#EAECEF] dark:border-[#21262D]">
              <span>Logged: <strong className="tabular-nums font-semibold text-[#14181C] dark:text-white">{todayLogged.carbs}g</strong></span>
              <span>Target: <strong className="tabular-nums font-semibold text-[#14181C] dark:text-white">{targets.carbs}g</strong></span>
            </div>

            {/* Micro progress line */}
            <div className="w-full h-1 bg-[#D4A017]/15 rounded-full mt-2.5 overflow-hidden">
              <div
                className="h-full bg-[#D4A017] rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${Math.min(100, carbPercent)}%` }}
              />
            </div>
          </div>

          {/* Fat */}
          <div className="relative p-4 rounded-xl border border-[#E2E4E8] dark:border-[#22272E] bg-white/70 dark:bg-[#161B22]/70 backdrop-blur-sm hover:border-[#3E7C6B]/50 transition-colors">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#3E7C6B]" />
                <span className="text-xs font-semibold text-[#14181C] dark:text-white">
                  Fat
                </span>
              </div>
              <span className="text-[11px] font-semibold tabular-nums text-[#3E7C6B] dark:text-teal-400">
                {fatPercent}%
              </span>
            </div>

            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-3xl font-extrabold tabular-nums tracking-tight text-[#14181C] dark:text-white">
                {remainingMacros.fat}
              </span>
              <span className="text-xs font-medium text-[#6E7781] dark:text-[#8B949E]">g left</span>
            </div>

            <div className="mt-3 flex items-center justify-between text-[11px] text-[#6E7781] dark:text-[#8B949E] pt-2 border-t border-[#EAECEF] dark:border-[#21262D]">
              <span>Logged: <strong className="tabular-nums font-semibold text-[#14181C] dark:text-white">{todayLogged.fat}g</strong></span>
              <span>Target: <strong className="tabular-nums font-semibold text-[#14181C] dark:text-white">{targets.fat}g</strong></span>
            </div>

            {/* Micro progress line */}
            <div className="w-full h-1 bg-[#3E7C6B]/15 rounded-full mt-2.5 overflow-hidden">
              <div
                className="h-full bg-[#3E7C6B] rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${Math.min(100, fatPercent)}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
