import React, { useRef, useState } from 'react';
import {
  X,
  Upload,
  Sparkles,
  Plus,
  Trash2,
  Check,
  Camera,
  Layers,
  Barcode,
  AlertCircle,
  FileText,
  Clock,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { StorageLocation } from '../../types';
import { addDaysToDate } from '../../utils/nutrition';

interface PantryScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanCompleteNavigateToRecipes?: () => void;
}

interface DetectedItemDraft {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  category: string;
  daysUntilExpiration: number;
  location: StorageLocation;
  confirmed: boolean;
}

export const PantryScannerModal: React.FC<PantryScannerModalProps> = ({
  isOpen,
  onClose,
  onScanCompleteNavigateToRecipes,
}) => {
  const { bulkAddPantryItems } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Uploaded photos
  const [photos, setPhotos] = useState<Array<{ name: string; base64: string; mimeType: string }>>([]);
  const [selectedStorage, setSelectedStorage] = useState<StorageLocation>('fridge');
  const [isScanning, setIsScanning] = useState(false);
  const [scanError, setScanError] = useState<string | null>(null);

  // Editable checklist results
  const [detectedItems, setDetectedItems] = useState<DetectedItemDraft[]>([]);
  const [isChecklistStep, setIsChecklistStep] = useState(false);

  // Manual / Barcode alternative input
  const [altMode, setAltMode] = useState<'photo' | 'barcode' | 'text'>('photo');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [quickTextInput, setQuickTextInput] = useState('');

  if (!isOpen) return null;

  // Handle Photo Picker
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;

    const files = Array.from(e.target.files);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        if (base64) {
          setPhotos((prev) => [
            ...prev,
            { name: file.name, base64, mimeType: file.type || 'image/jpeg' },
          ]);
        }
      };
      reader.readAsDataURL(file);
    });

    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  // Perform AI Scan via backend
  const handleStartScan = async () => {
    if (photos.length === 0) return;

    setIsScanning(true);
    setScanError(null);

    try {
      const response = await fetch('/api/pantry/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          images: photos,
          storageType: selectedStorage,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || 'Failed to scan photos');
      }

      const data = await response.json();
      const items: any[] = data.items || [];

      if (items.length === 0) {
        throw new Error('No grocery or food items were identified. Try uploading a clearer, well-lit photo.');
      }

      const drafts: DetectedItemDraft[] = items.map((item, idx) => ({
        id: 'draft_' + idx + '_' + Date.now(),
        name: item.name || 'Pantry Item',
        quantity: item.quantity || 1,
        unit: item.unit || 'count',
        category: item.category || 'Produce',
        daysUntilExpiration: item.daysUntilExpiration || 7,
        location: (item.location as StorageLocation) || selectedStorage,
        confirmed: true,
      }));

      setDetectedItems(drafts);
      setIsChecklistStep(true);
    } catch (err: any) {
      console.error('Scan error:', err);
      setScanError(err?.message || 'Error communicating with vision server.');
    } finally {
      setIsScanning(false);
    }
  };

  // Handle Quick Manual Text / Barcode submit
  const handleQuickManualSubmit = () => {
    if (altMode === 'barcode') {
      if (!barcodeInput.trim()) return;
      // Parse barcode simulation
      const draft: DetectedItemDraft = {
        id: 'draft_bar_' + Date.now(),
        name: `Item (${barcodeInput.trim()})`,
        quantity: 1,
        unit: 'item',
        category: 'Pantry Staples',
        daysUntilExpiration: 30,
        location: selectedStorage,
        confirmed: true,
      };
      setDetectedItems([draft]);
      setIsChecklistStep(true);
    } else if (altMode === 'text') {
      if (!quickTextInput.trim()) return;
      // Split by commas or lines
      const names = quickTextInput
        .split(/[,\n]/)
        .map((s) => s.trim())
        .filter((s) => s.length > 0);

      const drafts: DetectedItemDraft[] = names.map((name, idx) => ({
        id: 'draft_text_' + idx + '_' + Date.now(),
        name,
        quantity: 1,
        unit: 'item',
        category: 'Produce',
        daysUntilExpiration: 7,
        location: selectedStorage,
        confirmed: true,
      }));

      setDetectedItems(drafts);
      setIsChecklistStep(true);
    }
  };

  // Checklist updates
  const toggleItemConfirmed = (id: string) => {
    setDetectedItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, confirmed: !item.confirmed } : item))
    );
  };

  const updateItemField = (id: string, field: keyof DetectedItemDraft, value: any) => {
    setDetectedItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const removeItem = (id: string) => {
    setDetectedItems((prev) => prev.filter((item) => item.id !== id));
  };

  const addManualMissedItem = () => {
    const newItem: DetectedItemDraft = {
      id: 'draft_manual_' + Date.now(),
      name: '',
      quantity: 1,
      unit: 'count',
      category: 'Produce',
      daysUntilExpiration: 7,
      location: selectedStorage,
      confirmed: true,
    };
    setDetectedItems((prev) => [...prev, newItem]);
  };

  // Final Confirmation into Pantry Inventory
  const handleConfirmAndSave = (proceedToRecipes = false) => {
    const confirmed = detectedItems.filter((i) => i.confirmed && i.name.trim().length > 0);
    if (confirmed.length === 0) {
      onClose();
      return;
    }

    const pantryEntries = confirmed.map((c) => ({
      name: c.name.trim(),
      quantity: Number(c.quantity) || 1,
      unit: c.unit.trim() || 'count',
      category: c.category,
      expirationDate: addDaysToDate(c.daysUntilExpiration),
      location: c.location,
      confidenceSource: 'photo_scan' as const,
    }));

    bulkAddPantryItems(pantryEntries);
    onClose();

    if (proceedToRecipes && onScanCompleteNavigateToRecipes) {
      onScanCompleteNavigateToRecipes();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-3xl bg-white dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#EAECEF] dark:border-[#21262D]">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] flex items-center justify-center">
              <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#14181C] dark:text-white">
                {isChecklistStep ? 'Confirm Detected Ingredients' : 'AI Pantry & Fridge Scanner'}
              </h2>
              <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                {isChecklistStep
                  ? 'Verify, adjust portions, and check off items to save into your inventory'
                  : 'Desktop photo upload with vision recognition (multiple photos supported)'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#6E7781] hover:text-[#14181C] dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#22272E] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {!isChecklistStep ? (
            /* STEP 1: PHOTO UPLOADER OR ALTERNATIVES */
            <div className="space-y-6">
              {/* Method Switcher Tabs */}
              <div className="flex items-center gap-1 p-1 bg-[#F2F4F7] dark:bg-[#0D1117] rounded-xl max-w-sm">
                <button
                  onClick={() => setAltMode('photo')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    altMode === 'photo'
                      ? 'bg-white dark:bg-[#21262D] text-[#14181C] dark:text-white shadow-xs'
                      : 'text-[#57606A] dark:text-[#8B949E]'
                  }`}
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Photos</span>
                </button>
                <button
                  onClick={() => setAltMode('text')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    altMode === 'text'
                      ? 'bg-white dark:bg-[#21262D] text-[#14181C] dark:text-white shadow-xs'
                      : 'text-[#57606A] dark:text-[#8B949E]'
                  }`}
                >
                  <FileText className="w-3.5 h-3.5" />
                  <span>Text List</span>
                </button>
                <button
                  onClick={() => setAltMode('barcode')}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    altMode === 'barcode'
                      ? 'bg-white dark:bg-[#21262D] text-[#14181C] dark:text-white shadow-xs'
                      : 'text-[#57606A] dark:text-[#8B949E]'
                  }`}
                >
                  <Barcode className="w-3.5 h-3.5" />
                  <span>Barcode</span>
                </button>
              </div>

              {/* Storage Zone Selector */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Target Storage Location
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(['fridge', 'pantry', 'freezer'] as StorageLocation[]).map((loc) => (
                    <button
                      key={loc}
                      type="button"
                      onClick={() => setSelectedStorage(loc)}
                      className={`p-3 rounded-xl border text-left capitalize transition-all cursor-pointer ${
                        selectedStorage === loc
                          ? 'border-[#14181C] dark:border-white bg-[#F6F8FA] dark:bg-[#1C2128] font-bold text-[#14181C] dark:text-white ring-1 ring-[#14181C] dark:ring-white'
                          : 'border-[#E2E4E8] dark:border-[#22272E] text-[#57606A] dark:text-[#8B949E] hover:border-slate-400'
                      }`}
                    >
                      <div className="text-xs">{loc}</div>
                      <div className="text-[10px] text-[#6E7781] dark:text-[#768390] font-normal">
                        {loc === 'fridge'
                          ? 'Dairy, meats, fresh veggies'
                          : loc === 'pantry'
                          ? 'Grains, canned goods, spices'
                          : 'Frozen proteins, vegetables'}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Photo Mode Content */}
              {altMode === 'photo' && (
                <div className="space-y-4">
                  {/* Dropzone / Upload Trigger */}
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-[#D0D7DE] dark:border-[#30363D] hover:border-[#14181C] dark:hover:border-white rounded-2xl p-8 text-center cursor-pointer transition-colors bg-[#F6F8FA] dark:bg-[#0D1117] group"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <div className="w-12 h-12 rounded-xl bg-white dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#30363D] flex items-center justify-center mx-auto mb-3 text-[#14181C] dark:text-white group-hover:scale-105 transition-transform">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div className="text-sm font-semibold text-[#14181C] dark:text-white">
                      Click to choose photo(s) from your computer
                    </div>
                    <p className="text-xs text-[#6E7781] dark:text-[#8B949E] mt-1 max-w-md mx-auto">
                      Upload your fridge, freezer, or pantry shelf pictures. You can upload multiple angles or sections in one go.
                    </p>
                  </div>

                  {/* Selected Photos Preview List */}
                  {photos.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                        <span>Selected Photos ({photos.length})</span>
                        <button
                          onClick={() => fileInputRef.current?.click()}
                          className="text-[11px] text-[#A6243D] dark:text-rose-400 hover:underline cursor-pointer"
                        >
                          + Add another photo
                        </button>
                      </div>

                      <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                        {photos.map((p, idx) => (
                          <div
                            key={idx}
                            className="relative group rounded-xl overflow-hidden border border-[#E2E4E8] dark:border-[#22272E] bg-black aspect-square"
                          >
                            <img
                              src={p.base64}
                              alt={p.name}
                              className="w-full h-full object-cover opacity-90 group-hover:opacity-100 transition-opacity"
                            />
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                removePhoto(idx);
                              }}
                              className="absolute top-1.5 right-1.5 p-1 rounded-md bg-black/70 text-white hover:bg-red-600 transition-colors cursor-pointer"
                              title="Remove photo"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                            <span className="absolute bottom-1 left-1.5 right-1.5 text-[10px] text-white/90 truncate font-mono bg-black/60 px-1 py-0.5 rounded-sm">
                              {p.name}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Error display */}
                  {scanError && (
                    <div className="flex items-start gap-2.5 p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-300 text-xs">
                      <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                      <div>
                        <strong>Scan Failed:</strong> {scanError}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Text List Alternative */}
              {altMode === 'text' && (
                <div className="space-y-3">
                  <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                    Paste or Type Ingredients (Comma or line separated)
                  </label>
                  <textarea
                    rows={4}
                    placeholder="e.g. Chicken breast, 12 eggs, Greek yogurt, spinach, rolled oats, sweet potatoes"
                    value={quickTextInput}
                    onChange={(e) => setQuickTextInput(e.target.value)}
                    className="w-full p-3 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white placeholder-[#8B949E] focus:outline-hidden focus:border-[#14181C] dark:focus:border-white"
                  />
                </div>
              )}

              {/* Barcode Alternative */}
              {altMode === 'barcode' && (
                <div className="space-y-3">
                  <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                    Manual Barcode or Product Code
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. 012345678905 or UPC code"
                      value={barcodeInput}
                      onChange={(e) => setBarcodeInput(e.target.value)}
                      className="flex-1 px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden focus:border-[#14181C] dark:focus:border-white font-mono"
                    />
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* STEP 2: EDITABLE CHECKLIST */
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Identified {detectedItems.length} ingredients. Edit details or uncheck unwanted items.
                </span>
                <button
                  type="button"
                  onClick={addManualMissedItem}
                  className="flex items-center gap-1 text-xs font-semibold text-[#A6243D] dark:text-rose-400 hover:underline cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Missed Item</span>
                </button>
              </div>

              {/* Checklist Table */}
              <div className="border border-[#E2E4E8] dark:border-[#22272E] rounded-xl overflow-hidden divide-y divide-[#EAECEF] dark:divide-[#21262D]">
                {detectedItems.map((item) => (
                  <div
                    key={item.id}
                    className={`flex items-center gap-3 p-3 transition-colors ${
                      item.confirmed
                        ? 'bg-white dark:bg-[#161B22]'
                        : 'bg-slate-50 dark:bg-[#0D1117]/60 opacity-50'
                    }`}
                  >
                    {/* Confirm Checkbox */}
                    <button
                      type="button"
                      onClick={() => toggleItemConfirmed(item.id)}
                      className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 cursor-pointer transition-colors ${
                        item.confirmed
                          ? 'bg-[#14181C] dark:bg-white border-[#14181C] dark:border-white text-white dark:text-[#14181C]'
                          : 'border-slate-300 dark:border-slate-600 bg-transparent'
                      }`}
                    >
                      {item.confirmed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </button>

                    {/* Item Name */}
                    <div className="flex-1 min-w-[140px]">
                      <input
                        type="text"
                        value={item.name}
                        onChange={(e) => updateItemField(item.id, 'name', e.target.value)}
                        placeholder="Ingredient name"
                        className="w-full text-xs font-semibold bg-transparent text-[#14181C] dark:text-white border-b border-transparent hover:border-slate-300 dark:hover:border-slate-600 focus:border-[#14181C] dark:focus:border-white focus:outline-hidden py-0.5"
                      />
                    </div>

                    {/* Quantity & Unit */}
                    <div className="flex items-center gap-1.5 w-28 shrink-0">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={item.quantity}
                        onChange={(e) =>
                          updateItemField(item.id, 'quantity', parseFloat(e.target.value) || 1)
                        }
                        className="w-12 px-1.5 py-0.5 text-xs text-center tabular-nums rounded border border-[#E1E4E8] dark:border-[#30363D] bg-[#F6F8FA] dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                      />
                      <input
                        type="text"
                        value={item.unit}
                        onChange={(e) => updateItemField(item.id, 'unit', e.target.value)}
                        placeholder="unit"
                        className="w-14 px-1.5 py-0.5 text-xs text-center rounded border border-[#E1E4E8] dark:border-[#30363D] bg-[#F6F8FA] dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                      />
                    </div>

                    {/* Expiration Days estimate */}
                    <div className="flex items-center gap-1 w-24 shrink-0 text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                      <Clock className="w-3 h-3 text-[#D4A017]" />
                      <input
                        type="number"
                        min="1"
                        max="365"
                        value={item.daysUntilExpiration}
                        onChange={(e) =>
                          updateItemField(
                            item.id,
                            'daysUntilExpiration',
                            parseInt(e.target.value) || 7
                          )
                        }
                        className="w-10 px-1 py-0.5 text-xs text-center tabular-nums rounded border border-[#E1E4E8] dark:border-[#30363D] bg-[#F6F8FA] dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                      />
                      <span>days</span>
                    </div>

                    {/* Storage selector */}
                    <select
                      value={item.location}
                      onChange={(e) => updateItemField(item.id, 'location', e.target.value as any)}
                      className="text-[11px] px-2 py-1 rounded border border-[#E1E4E8] dark:border-[#30363D] bg-[#F6F8FA] dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden capitalize"
                    >
                      <option value="fridge">Fridge</option>
                      <option value="pantry">Pantry</option>
                      <option value="freezer">Freezer</option>
                    </select>

                    {/* Delete item */}
                    <button
                      type="button"
                      onClick={() => removeItem(item.id)}
                      className="p-1 rounded text-[#6E7781] hover:text-[#A6243D] transition-colors"
                      title="Remove from scan"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Actions */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-[#EAECEF] dark:border-[#21262D] bg-[#FAFAF7] dark:bg-[#111417]">
          {!isChecklistStep ? (
            <>
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-[#57606A] dark:text-[#8B949E] hover:bg-slate-200 dark:hover:bg-[#22272E] rounded-lg transition-colors cursor-pointer"
              >
                Cancel
              </button>

              {altMode === 'photo' ? (
                <button
                  type="button"
                  disabled={photos.length === 0 || isScanning}
                  onClick={handleStartScan}
                  className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] font-semibold text-xs transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-xs"
                >
                  {isScanning ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      <span>Analyzing Photo(s) with Vision...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
                      <span>Scan {photos.length} Photo{photos.length !== 1 ? 's' : ''}</span>
                    </>
                  )}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleQuickManualSubmit}
                  className="px-5 py-2.5 rounded-xl bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] font-semibold text-xs hover:opacity-90 transition-opacity cursor-pointer shadow-xs"
                >
                  Continue to Checklist
                </button>
              )}
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setIsChecklistStep(false)}
                className="px-4 py-2 text-xs font-semibold text-[#57606A] dark:text-[#8B949E] hover:bg-slate-200 dark:hover:bg-[#22272E] rounded-lg transition-colors cursor-pointer"
              >
                Back to Photos
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleConfirmAndSave(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-lg border border-[#E2E4E8] dark:border-[#30363D] text-[#14181C] dark:text-white hover:bg-slate-100 dark:hover:bg-[#22272E] transition-colors cursor-pointer"
                >
                  Save to My Pantry
                </button>

                <button
                  type="button"
                  onClick={() => handleConfirmAndSave(true)}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] font-semibold text-xs transition-colors cursor-pointer shadow-xs"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
                  <span>Save & Generate Recipes</span>
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
