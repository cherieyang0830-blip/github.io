import React, { useMemo, useState } from 'react';
import {
  Plus,
  Search,
  Filter,
  Trash2,
  Edit2,
  Sparkles,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowUpDown,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { PantryItem, StorageLocation, UrgencyStatus } from '../../types';
import {
  addDaysToDate,
  formatDatePretty,
  getDaysUntilExpiration,
  getUrgencyStatus,
} from '../../utils/nutrition';

interface PantryInventoryProps {
  onOpenScanner: () => void;
  onNavigateToRecipes: () => void;
}

export const PantryInventory: React.FC<PantryInventoryProps> = ({
  onOpenScanner,
  onNavigateToRecipes,
}) => {
  const { pantry, addPantryItem, updatePantryItem, deletePantryItem } = useApp();

  // Search & Filters
  const [search, setSearch] = useState('');
  const [locationFilter, setLocationFilter] = useState<'all' | StorageLocation>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<'all' | UrgencyStatus>('all');

  // Manual Add Form Modal State
  const [isAddManualOpen, setIsAddManualOpen] = useState(false);
  const [newItemName, setNewItemName] = useState('');
  const [newItemQty, setNewItemQty] = useState('1');
  const [newItemUnit, setNewItemUnit] = useState('count');
  const [newItemCategory, setNewItemCategory] = useState('Produce');
  const [newItemLoc, setNewItemLoc] = useState<StorageLocation>('fridge');
  const [newItemDays, setNewItemDays] = useState('7');

  // Editing inline state
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editQty, setEditQty] = useState('');
  const [editDays, setEditDays] = useState('');

  // Process and sort pantry items (urgency sorted first)
  const sortedAndFilteredItems = useMemo(() => {
    return pantry
      .map((item) => {
        const days = getDaysUntilExpiration(item.expirationDate);
        const urgency = getUrgencyStatus(days);
        return { ...item, daysLeft: days, urgency };
      })
      .filter((item) => {
        if (search && !item.name.toLowerCase().includes(search.toLowerCase())) return false;
        if (locationFilter !== 'all' && item.location !== locationFilter) return false;
        if (urgencyFilter !== 'all' && item.urgency !== urgencyFilter) return false;
        return true;
      })
      .sort((a, b) => {
        // Expired (-1, -2, etc) first, then use_soon (0 to 3 days), then fresh
        return a.daysLeft - b.daysLeft;
      });
  }, [pantry, search, locationFilter, urgencyFilter]);

  const handleManualAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    addPantryItem({
      name: newItemName.trim(),
      quantity: parseFloat(newItemQty) || 1,
      unit: newItemUnit.trim() || 'count',
      category: newItemCategory,
      expirationDate: addDaysToDate(parseInt(newItemDays) || 7),
      location: newItemLoc,
      confidenceSource: 'manual',
    });

    setNewItemName('');
    setIsAddManualOpen(false);
  };

  const handleSaveInlineEdit = (id: string) => {
    const updates: Partial<PantryItem> = {};
    if (editQty) updates.quantity = parseFloat(editQty) || 1;
    if (editDays) updates.expirationDate = addDaysToDate(parseInt(editDays) || 7);
    updatePantryItem(id, updates);
    setEditingId(null);
  };

  const urgentCount = pantry.filter(
    (p) => getUrgencyStatus(getDaysUntilExpiration(p.expirationDate)) === 'use_soon'
  ).length;

  const expiredCount = pantry.filter(
    (p) => getUrgencyStatus(getDaysUntilExpiration(p.expirationDate)) === 'expired'
  ).length;

  return (
    <div className="space-y-6">
      {/* Top Banner / Actions Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#14181C] dark:text-white">
            My Pantry & Storage
          </h1>
          <p className="text-xs text-[#6E7781] dark:text-[#8B949E] mt-0.5">
            {pantry.length} tracked ingredients across fridge, freezer, and pantry. Sorted by freshness.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setIsAddManualOpen(true)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl border border-[#E2E4E8] dark:border-[#30363D] bg-white dark:bg-[#161B22] text-[#14181C] dark:text-white text-xs font-semibold hover:bg-slate-50 dark:hover:bg-[#21262D] transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Item</span>
          </button>

          <button
            onClick={onOpenScanner}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-semibold transition-colors cursor-pointer shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
            <span>Scan Photo</span>
          </button>
        </div>
      </div>

      {/* Freshness Radar Alert Banner if items need urgent use */}
      {(urgentCount > 0 || expiredCount > 0) && (
        <div className="p-4 rounded-xl border border-[#D4A017]/30 bg-[#D4A017]/5 dark:bg-[#D4A017]/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-[#D4A017]/20 text-[#D4A017] dark:text-amber-400 shrink-0">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-[#14181C] dark:text-white">
                Leftover & Urgency Radar
              </div>
              <div className="text-[11px] text-[#57606A] dark:text-[#8B949E]">
                {urgentCount > 0 && `${urgentCount} item(s) expiring within 3 days. `}
                {expiredCount > 0 && `${expiredCount} item(s) past expiration. `}
                Generate recipes to utilize them before waste occurs.
              </div>
            </div>
          </div>

          <button
            onClick={onNavigateToRecipes}
            className="px-3.5 py-1.5 rounded-lg bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] text-xs font-semibold hover:opacity-90 transition-opacity cursor-pointer shrink-0"
          >
            Cook Expiring Items
          </button>
        </div>
      )}

      {/* Search & Location Filter Segmented Control */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#6E7781]" />
          <input
            type="text"
            placeholder="Search ingredients in your pantry..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#161B22] text-[#14181C] dark:text-white placeholder-[#8B949E] focus:outline-hidden focus:border-[#14181C] dark:focus:border-white"
          />
        </div>

        {/* Filter controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Location segmented controls */}
          <div className="flex items-center gap-1 p-1 bg-[#F2F4F7] dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E] rounded-xl text-xs">
            {(['all', 'fridge', 'pantry', 'freezer'] as const).map((loc) => (
              <button
                key={loc}
                onClick={() => setLocationFilter(loc)}
                className={`px-3 py-1 font-medium rounded-lg capitalize transition-colors cursor-pointer ${
                  locationFilter === loc
                    ? 'bg-white dark:bg-[#21262D] text-[#14181C] dark:text-white shadow-xs font-semibold'
                    : 'text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white'
                }`}
              >
                {loc}
              </button>
            ))}
          </div>

          {/* Urgency filter */}
          <select
            value={urgencyFilter}
            onChange={(e) => setUrgencyFilter(e.target.value as any)}
            className="px-2.5 py-1.5 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#161B22] text-[#14181C] dark:text-white focus:outline-hidden"
          >
            <option value="all">All Freshness</option>
            <option value="use_soon">Use Soon (&le;3 days)</option>
            <option value="fresh">Fresh (&gt;3 days)</option>
            <option value="expired">Expired</option>
          </select>
        </div>
      </div>

      {/* Inventory Table / Grid (Desktop Optimized) */}
      <div className="border border-[#E2E4E8] dark:border-[#22272E] rounded-2xl bg-white dark:bg-[#161B22] overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#EAECEF] dark:border-[#21262D] bg-[#FAFAF7] dark:bg-[#0D1117]/60 text-[11px] font-semibold text-[#57606A] dark:text-[#8B949E]">
                <th className="py-3 px-4">Item & Category</th>
                <th className="py-3 px-4">Location</th>
                <th className="py-3 px-4">Stock Quantity</th>
                <th className="py-3 px-4">Urgency & Shelf Life</th>
                <th className="py-3 px-4">Source</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EAECEF] dark:divide-[#21262D] text-xs">
              {sortedAndFilteredItems.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-[#6E7781] dark:text-[#8B949E]">
                    No ingredients match the search or filter criteria.
                  </td>
                </tr>
              ) : (
                sortedAndFilteredItems.map((item) => {
                  const isEditing = editingId === item.id;

                  return (
                    <tr
                      key={item.id}
                      className="hover:bg-[#F6F8FA] dark:hover:bg-[#1C2128]/50 transition-colors group"
                    >
                      {/* Name & Category */}
                      <td className="py-3 px-4">
                        <div className="font-semibold text-[#14181C] dark:text-white">
                          {item.name}
                        </div>
                        <div className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                          {item.category}
                        </div>
                      </td>

                      {/* Location */}
                      <td className="py-3 px-4">
                        <span className="capitalize text-[11px] font-medium text-[#57606A] dark:text-[#8B949E]">
                          {item.location}
                        </span>
                      </td>

                      {/* Quantity */}
                      <td className="py-3 px-4">
                        {isEditing ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              value={editQty}
                              onChange={(e) => setEditQty(e.target.value)}
                              className="w-16 px-1.5 py-0.5 text-xs border rounded bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white"
                            />
                            <span className="text-[11px] text-[#6E7781]">{item.unit}</span>
                          </div>
                        ) : (
                          <span className="tabular-nums font-semibold text-[#14181C] dark:text-white">
                            {item.quantity} {item.unit}
                          </span>
                        )}
                      </td>

                      {/* Urgency & Shelf Life */}
                      <td className="py-3 px-4">
                        {isEditing ? (
                          <div className="flex items-center gap-1 text-[11px]">
                            <input
                              type="number"
                              value={editDays}
                              onChange={(e) => setEditDays(e.target.value)}
                              placeholder="Days"
                              className="w-14 px-1.5 py-0.5 text-xs border rounded bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white"
                            />
                            <span>days left</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2">
                            {/* Unboxed clean urgency indicator adhering to zero-pill constitution */}
                            <span
                              className={`w-2 h-2 rounded-full shrink-0 ${
                                item.urgency === 'expired'
                                  ? 'bg-[#A6243D]'
                                  : item.urgency === 'use_soon'
                                  ? 'bg-[#D4A017]'
                                  : 'bg-[#3E7C6B]'
                              }`}
                            />
                            <span
                              className={`text-xs font-semibold ${
                                item.urgency === 'expired'
                                  ? 'text-[#A6243D] dark:text-rose-400'
                                  : item.urgency === 'use_soon'
                                  ? 'text-[#D4A017] dark:text-amber-400'
                                  : 'text-[#3E7C6B] dark:text-teal-400'
                              }`}
                            >
                              {item.urgency === 'expired'
                                ? 'Expired'
                                : item.urgency === 'use_soon'
                                ? `Use soon (${item.daysLeft}d left)`
                                : `Fresh (${item.daysLeft}d)`}
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Source */}
                      <td className="py-3 px-4 text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                        {item.confidenceSource === 'photo_scan'
                          ? 'AI Vision'
                          : item.confidenceSource === 'barcode'
                          ? 'Barcode'
                          : 'Manual'}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1 opacity-80 sm:opacity-0 group-hover:opacity-100 transition-opacity">
                          {isEditing ? (
                            <button
                              onClick={() => handleSaveInlineEdit(item.id)}
                              className="px-2 py-0.5 text-[11px] font-semibold bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] rounded-md"
                            >
                              Save
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                setEditingId(item.id);
                                setEditQty(String(item.quantity));
                                setEditDays(String(item.daysLeft));
                              }}
                              className="p-1 rounded text-[#6E7781] hover:text-[#14181C] dark:hover:text-white"
                              title="Edit item"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            onClick={() => deletePantryItem(item.id)}
                            className="p-1 rounded text-[#6E7781] hover:text-[#A6243D]"
                            title="Delete item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Manual Item Add Modal */}
      {isAddManualOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E] rounded-2xl shadow-xl overflow-hidden p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#EAECEF] dark:border-[#21262D]">
              <h2 className="text-sm font-bold text-[#14181C] dark:text-white">
                Add Ingredient Manually
              </h2>
              <button
                onClick={() => setIsAddManualOpen(false)}
                className="text-[#6E7781] hover:text-[#14181C] dark:hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleManualAddSubmit} className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                  Ingredient Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Grass-Fed Sirloin Steak"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                    Quantity
                  </label>
                  <input
                    type="number"
                    step="any"
                    value={newItemQty}
                    onChange={(e) => setNewItemQty(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                    Unit
                  </label>
                  <input
                    type="text"
                    placeholder="g, ml, count, cans"
                    value={newItemUnit}
                    onChange={(e) => setNewItemUnit(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                    Location
                  </label>
                  <select
                    value={newItemLoc}
                    onChange={(e) => setNewItemLoc(e.target.value as any)}
                    className="w-full px-2.5 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white capitalize focus:outline-hidden"
                  >
                    <option value="fridge">Fridge</option>
                    <option value="pantry">Pantry</option>
                    <option value="freezer">Freezer</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                    Expires In (Days)
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={newItemDays}
                    onChange={(e) => setNewItemDays(e.target.value)}
                    className="w-full px-3 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                  Category
                </label>
                <select
                  value={newItemCategory}
                  onChange={(e) => setNewItemCategory(e.target.value)}
                  className="w-full px-2.5 py-2 text-xs rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                >
                  <option value="Produce">Produce</option>
                  <option value="Meat & Poultry">Meat & Poultry</option>
                  <option value="Fish & Seafood">Fish & Seafood</option>
                  <option value="Dairy & Eggs">Dairy & Eggs</option>
                  <option value="Grains & Pasta">Grains & Pasta</option>
                  <option value="Canned Goods">Canned Goods</option>
                  <option value="Condiments & Oils">Condiments & Oils</option>
                  <option value="Baking & Spices">Baking & Spices</option>
                  <option value="Frozen">Frozen</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#EAECEF] dark:border-[#21262D]">
                <button
                  type="button"
                  onClick={() => setIsAddManualOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-[#57606A] dark:text-[#8B949E]"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold rounded-lg bg-[#14181C] dark:bg-white text-white dark:text-[#14181C]"
                >
                  Add Ingredient
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
