import React, { useState } from 'react';
import { Sparkles, Calculator, ArrowRight, Check } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  ActivityLevel,
  CookingSkill,
  FitnessGoal,
  TimeBudget,
  UserProfile,
} from '../../types';
import { calculateSuggestedMacros } from '../../utils/nutrition';

const DIETARY_OPTIONS = [
  'none',
  'high-protein',
  'vegan',
  'vegetarian',
  'keto',
  'gluten-free',
  'dairy-free',
  'halal',
  'kosher',
];

export const OnboardingModal: React.FC = () => {
  const { user, updateUser } = useApp();

  // If already onboarded, don't show
  if (user.onboarded) return null;

  const [step, setStep] = useState<1 | 2>(1);

  // Form draft
  const [name, setName] = useState(user.name || '');
  const [age, setAge] = useState(user.age || 28);
  const [sex, setSex] = useState<'male' | 'female' | 'other'>(user.sex || 'male');
  const [heightCm, setHeightCm] = useState(user.heightCm || 178);
  const [weightKg, setWeightKg] = useState(user.weightKg || 76);
  const [activityLevel, setActivityLevel] = useState<ActivityLevel>(
    user.activityLevel || 'moderately_active'
  );
  const [goal, setGoal] = useState<FitnessGoal>(user.goal || 'lose_fat');

  // Targets (auto-calculated initially)
  const initialTargets = calculateSuggestedMacros({
    age: user.age || 28,
    sex: user.sex || 'male',
    heightCm: user.heightCm || 178,
    weightKg: user.weightKg || 76,
    activityLevel: user.activityLevel || 'moderately_active',
    goal: user.goal || 'lose_fat',
  });

  const [calories, setCalories] = useState(initialTargets.calories);
  const [protein, setProtein] = useState(initialTargets.protein);
  const [carbs, setCarbs] = useState(initialTargets.carbs);
  const [fat, setFat] = useState(initialTargets.fat);

  const [dietary, setDietary] = useState<string[]>(['high-protein']);
  const [allergiesText, setAllergiesText] = useState('');
  const [cookingSkill, setCookingSkill] = useState<CookingSkill>('intermediate');
  const [householdSize, setHouseholdSize] = useState(1);
  const [timeBudget, setTimeBudget] = useState<TimeBudget>('15-30 min');

  const handleStep1Next = (e: React.FormEvent) => {
    e.preventDefault();
    // Recompute auto targets based on step 1 input
    const suggested = calculateSuggestedMacros({
      age,
      sex,
      heightCm,
      weightKg,
      activityLevel,
      goal,
    });
    setCalories(suggested.calories);
    setProtein(suggested.protein);
    setCarbs(suggested.carbs);
    setFat(suggested.fat);
    setStep(2);
  };

  const handleRecalculate = () => {
    const suggested = calculateSuggestedMacros({
      age,
      sex,
      heightCm,
      weightKg,
      activityLevel,
      goal,
    });
    setCalories(suggested.calories);
    setProtein(suggested.protein);
    setCarbs(suggested.carbs);
    setFat(suggested.fat);
  };

  const toggleDiet = (item: string) => {
    if (item === 'none') {
      setDietary(['none']);
      return;
    }
    const filtered = dietary.filter((d) => d !== 'none');
    if (filtered.includes(item)) {
      setDietary(filtered.filter((d) => d !== item));
    } else {
      setDietary([...filtered, item]);
    }
  };

  const handleFinalComplete = (e: React.FormEvent) => {
    e.preventDefault();
    const allergiesList = allergiesText
      .split(',')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);

    updateUser({
      name: name.trim() || 'Athlete',
      age,
      sex,
      heightCm,
      weightKg,
      activityLevel,
      goal,
      targets: {
        calories,
        protein,
        carbs,
        fat,
      },
      dietaryPreferences: dietary.length > 0 ? dietary : ['none'],
      allergies: allergiesList,
      cookingSkill,
      householdSize,
      timeBudget,
      onboarded: true,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md">
      <div className="w-full max-w-2xl bg-white dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E] rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 md:p-8 border-b border-[#EAECEF] dark:border-[#21262D] bg-[#FAFAF7] dark:bg-[#111417]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] flex items-center justify-center font-black text-base">
              PM
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-[#14181C] dark:text-white">
                  Welcome to PantryMacros
                </h1>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#14181C]/10 dark:bg-white/10 font-mono">
                  Step {step} of 2
                </span>
              </div>
              <p className="text-xs text-[#6E7781] dark:text-[#8B949E] mt-0.5">
                Precision macro tracking synchronized with AI vision pantry recipe creation.
              </p>
            </div>
          </div>
        </div>

        {/* STEP 1: Biometrics & Goal */}
        {step === 1 ? (
          <form onSubmit={handleStep1Next} className="p-6 md:p-8 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1 sm:col-span-2">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Your Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Alex"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Biological Sex
                </label>
                <select
                  value={sex}
                  onChange={(e) => setSex(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Age
                </label>
                <input
                  type="number"
                  min="14"
                  max="100"
                  value={age}
                  onChange={(e) => setAge(parseInt(e.target.value) || 25)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Height (cm)
                </label>
                <input
                  type="number"
                  min="100"
                  max="250"
                  value={heightCm}
                  onChange={(e) => setHeightCm(parseFloat(e.target.value) || 175)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Weight (kg)
                </label>
                <input
                  type="number"
                  step="0.1"
                  min="30"
                  max="250"
                  value={weightKg}
                  onChange={(e) => setWeightKg(parseFloat(e.target.value) || 75)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Activity Level
                </label>
                <select
                  value={activityLevel}
                  onChange={(e) => setActivityLevel(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                >
                  <option value="sedentary">Sedentary (mostly sitting)</option>
                  <option value="lightly_active">Lightly active (1-3 days exercise)</option>
                  <option value="moderately_active">Moderately active (3-5 days exercise)</option>
                  <option value="very_active">Very active (6-7 days intense)</option>
                  <option value="extra_active">Extra active (physical job + training)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Nutrition Goal
                </label>
                <select
                  value={goal}
                  onChange={(e) => setGoal(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                >
                  <option value="lose_fat">Lose fat (~20% calorie deficit)</option>
                  <option value="maintain">Maintain weight (equilibrium)</option>
                  <option value="build_muscle">Build muscle (~10% lean surplus)</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-4 border-t border-[#EAECEF] dark:border-[#21262D]">
              <button
                type="submit"
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] font-bold text-xs transition-colors cursor-pointer shadow-md"
              >
                <span>Continue to Target Calibration</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        ) : (
          /* STEP 2: Macro Calibration & Dietary Rules */
          <form onSubmit={handleFinalComplete} className="p-6 md:p-8 space-y-6">
            {/* Auto Calculated Macro Targets with Manual Override */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xs font-bold text-[#14181C] dark:text-white">
                    Suggested Daily Targets (Auto-Calculated)
                  </h2>
                  <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                    You can override any value manually below.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handleRecalculate}
                  className="flex items-center gap-1 text-[11px] font-semibold text-[#D4A017] hover:underline cursor-pointer"
                >
                  <Calculator className="w-3.5 h-3.5" />
                  <span>Recalculate</span>
                </button>
              </div>

              <div className="grid grid-cols-4 gap-2.5">
                <div className="p-3 rounded-xl border border-[#E2E4E8] dark:border-[#22272E] bg-[#F6F8FA] dark:bg-[#0D1117]">
                  <label className="text-[10px] font-bold uppercase text-[#6E7781] block">
                    Calories
                  </label>
                  <input
                    type="number"
                    value={calories}
                    onChange={(e) => setCalories(parseInt(e.target.value) || 0)}
                    className="w-full text-base font-extrabold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
                  />
                  <span className="text-[10px] text-[#6E7781]">kcal</span>
                </div>

                <div className="p-3 rounded-xl border border-[#A6243D]/30 bg-[#A6243D]/5 dark:bg-[#A6243D]/10">
                  <label className="text-[10px] font-bold uppercase text-[#A6243D] dark:text-rose-400 block">
                    Protein
                  </label>
                  <input
                    type="number"
                    value={protein}
                    onChange={(e) => setProtein(parseInt(e.target.value) || 0)}
                    className="w-full text-base font-extrabold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
                  />
                  <span className="text-[10px] text-[#A6243D] dark:text-rose-400 font-semibold">g</span>
                </div>

                <div className="p-3 rounded-xl border border-[#D4A017]/30 bg-[#D4A017]/5 dark:bg-[#D4A017]/10">
                  <label className="text-[10px] font-bold uppercase text-[#D4A017] dark:text-amber-400 block">
                    Carbs
                  </label>
                  <input
                    type="number"
                    value={carbs}
                    onChange={(e) => setCarbs(parseInt(e.target.value) || 0)}
                    className="w-full text-base font-extrabold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
                  />
                  <span className="text-[10px] text-[#D4A017] dark:text-amber-400 font-semibold">g</span>
                </div>

                <div className="p-3 rounded-xl border border-[#3E7C6B]/30 bg-[#3E7C6B]/5 dark:bg-[#3E7C6B]/10">
                  <label className="text-[10px] font-bold uppercase text-[#3E7C6B] dark:text-teal-400 block">
                    Fat
                  </label>
                  <input
                    type="number"
                    value={fat}
                    onChange={(e) => setFat(parseInt(e.target.value) || 0)}
                    className="w-full text-base font-extrabold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
                  />
                  <span className="text-[10px] text-[#3E7C6B] dark:text-teal-400 font-semibold">g</span>
                </div>
              </div>
            </div>

            {/* Dietary preferences */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E] block">
                Dietary Preferences
              </label>
              <div className="flex flex-wrap gap-2">
                {DIETARY_OPTIONS.map((item) => {
                  const sel = dietary.includes(item);
                  return (
                    <button
                      key={item}
                      type="button"
                      onClick={() => toggleDiet(item)}
                      className={`px-3 py-1 rounded-lg text-xs capitalize transition-colors cursor-pointer ${
                        sel
                          ? 'bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] font-semibold'
                          : 'border border-[#E2E4E8] dark:border-[#30363D] text-[#57606A] dark:text-[#8B949E]'
                      }`}
                    >
                      {item.replace('-', ' ')}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Allergies text */}
            <div className="space-y-1">
              <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                Allergies to strictly avoid (comma-separated)
              </label>
              <input
                type="text"
                placeholder="e.g. peanuts, shellfish, tree nuts"
                value={allergiesText}
                onChange={(e) => setAllergiesText(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            {/* Cooking skill, household size, time budget */}
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Skill Level
                </label>
                <select
                  value={cookingSkill}
                  onChange={(e) => setCookingSkill(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden capitalize"
                >
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Household Size
                </label>
                <input
                  type="number"
                  min="1"
                  max="10"
                  value={householdSize}
                  onChange={(e) => setHouseholdSize(parseInt(e.target.value) || 1)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E]">
                  Time Budget
                </label>
                <select
                  value={timeBudget}
                  onChange={(e) => setTimeBudget(e.target.value as any)}
                  className="w-full px-2.5 py-1.5 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
                >
                  <option value="under 15 min">Under 15 min</option>
                  <option value="15-30 min">15-30 min</option>
                  <option value="30-60 min">30-60 min</option>
                  <option value="no limit">No limit</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-[#EAECEF] dark:border-[#21262D]">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2 text-xs font-semibold text-[#57606A] dark:text-[#8B949E] hover:underline cursor-pointer"
              >
                Back
              </button>

              <button
                type="submit"
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] font-bold text-xs transition-colors cursor-pointer shadow-md"
              >
                <Check className="w-4 h-4" />
                <span>Start Tracking with PantryMacros</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
