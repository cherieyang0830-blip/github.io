import React from 'react';
import {
  LayoutDashboard,
  Refrigerator,
  ChefHat,
  ShoppingCart,
  TrendingUp,
  Settings,
  Flame,
  Sun,
  Moon,
  Sparkles,
  Leaf,
  DollarSign,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export type NavTab = 'dashboard' | 'pantry' | 'recipes' | 'grocery' | 'history' | 'settings';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  onOpenScanner: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, onOpenScanner }) => {
  const {
    user,
    streakCount,
    foodWasteStats,
    darkMode,
    toggleDarkMode,
    groceryList,
    pantry,
    remainingMacros,
  } = useApp();

  const urgentPantryCount = pantry.filter((p) => {
    const exp = new Date(p.expirationDate).getTime();
    const now = new Date().setHours(0, 0, 0, 0);
    const diff = Math.ceil((exp - now) / 86400000);
    return diff >= 0 && diff <= 3;
  }).length;

  const uncheckedGroceryCount = groceryList.filter((g) => !g.checked).length;

  const navItems: Array<{ id: NavTab; label: string; icon: React.ElementType; badge?: string | number; badgeColor?: string }> = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    {
      id: 'pantry',
      label: 'My Pantry',
      icon: Refrigerator,
      badge: urgentPantryCount > 0 ? `${urgentPantryCount} soon` : undefined,
      badgeColor: 'bg-[#A6243D]/15 text-[#A6243D] dark:text-rose-400',
    },
    { id: 'recipes', label: 'Recipe Engine', icon: ChefHat },
    {
      id: 'grocery',
      label: 'Grocery List',
      icon: ShoppingCart,
      badge: uncheckedGroceryCount > 0 ? uncheckedGroceryCount : undefined,
      badgeColor: 'bg-[#D4A017]/15 text-[#D4A017] dark:text-amber-400',
    },
    { id: 'history', label: 'History & Trends', icon: TrendingUp },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside className="w-64 h-screen sticky top-0 flex flex-col justify-between border-r border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#111417] px-4 py-6 select-none shrink-0 z-20">
      {/* Brand & Identity */}
      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#14181C] dark:bg-white flex items-center justify-center text-white dark:text-[#14181C] font-black text-sm tracking-tighter">
              PM
            </div>
            <div>
              <div className="font-bold text-base tracking-tight text-[#14181C] dark:text-white flex items-center gap-1.5">
                PantryMacros
                <span className="flex items-center gap-1 ml-1" title="Protein · Carbs · Fat">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#A6243D]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-[#D4A017]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-[#3E7C6B]" />
                </span>
              </div>
              <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E] font-medium">
                Macro-Engineered Cooking
              </p>
            </div>
          </div>
        </div>

        {/* Primary Action Button: Scan Pantry */}
        <div className="px-1">
          <button
            onClick={onOpenScanner}
            className="w-full flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-[#EAECEF] text-white dark:text-[#14181C] font-semibold text-xs transition-colors cursor-pointer group shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#D4A017] transition-transform group-hover:rotate-12" />
            <span>Scan Fridge / Pantry</span>
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-[#EAECEF] dark:bg-[#1E2329] text-[#14181C] dark:text-white font-semibold'
                    : 'text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white hover:bg-[#F2F4F7] dark:hover:bg-[#181C21]'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#14181C] dark:text-white' : 'text-[#6E7781] dark:text-[#768390]'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${
                      item.badgeColor || 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Live Macro Remaining Pill Preview */}
        <div className="p-3 rounded-xl bg-[#F6F8FA] dark:bg-[#161B22] border border-[#E1E4E8] dark:border-[#21262D]">
          <div className="flex items-center justify-between text-[11px] text-[#57606A] dark:text-[#8B949E] mb-2 font-medium">
            <span>Remaining Today</span>
            <span className="tabular-nums font-bold text-[#14181C] dark:text-white">
              {remainingMacros.calories} kcal
            </span>
          </div>
          <div className="grid grid-cols-3 gap-1.5 text-center">
            <div className="p-1.5 rounded-md bg-[#A6243D]/10 dark:bg-[#A6243D]/20">
              <span className="text-[10px] text-[#A6243D] dark:text-rose-400 font-bold block">P</span>
              <span className="tabular-nums text-xs font-bold text-[#14181C] dark:text-white">
                {remainingMacros.protein}g
              </span>
            </div>
            <div className="p-1.5 rounded-md bg-[#D4A017]/10 dark:bg-[#D4A017]/20">
              <span className="text-[10px] text-[#D4A017] dark:text-amber-400 font-bold block">C</span>
              <span className="tabular-nums text-xs font-bold text-[#14181C] dark:text-white">
                {remainingMacros.carbs}g
              </span>
            </div>
            <div className="p-1.5 rounded-md bg-[#3E7C6B]/10 dark:bg-[#3E7C6B]/20">
              <span className="text-[10px] text-[#3E7C6B] dark:text-teal-400 font-bold block">F</span>
              <span className="tabular-nums text-xs font-bold text-[#14181C] dark:text-white">
                {remainingMacros.fat}g
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Area: Streak & Food Waste & Theme Toggle */}
      <div className="space-y-3 pt-4 border-t border-[#E2E4E8] dark:border-[#22272E]">
        {/* Streak Counter & Food Waste Saved */}
        <div className="flex items-center justify-between text-xs px-2 text-[#57606A] dark:text-[#8B949E]">
          <div className="flex items-center gap-1.5" title="Consecutive days logged">
            <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
            <span className="font-semibold tabular-nums text-[#14181C] dark:text-white">
              {streakCount} day streak
            </span>
          </div>
          <div className="flex items-center gap-1 text-[11px]" title="Estimated saved food value">
            <Leaf className="w-3 h-3 text-[#3E7C6B]" />
            <span className="tabular-nums font-medium text-[#3E7C6B]">
              ${foodWasteStats.estimatedMoneySaved.toFixed(0)} saved
            </span>
          </div>
        </div>

        {/* User Card & Dark Mode Button */}
        <div className="flex items-center justify-between p-2 rounded-xl bg-[#F6F8FA] dark:bg-[#161B22] border border-[#E1E4E8] dark:border-[#21262D]">
          <div
            onClick={() => setActiveTab('settings')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity truncate mr-2"
          >
            <div className="w-7 h-7 rounded-full bg-[#A6243D] text-white flex items-center justify-center font-bold text-xs uppercase shrink-0">
              {user.name ? user.name[0] : 'U'}
            </div>
            <div className="truncate">
              <div className="text-xs font-semibold text-[#14181C] dark:text-white truncate">
                {user.name || 'Athlete'}
              </div>
              <div className="text-[10px] text-[#6E7781] dark:text-[#8B949E] capitalize truncate">
                {user.goal.replace('_', ' ')}
              </div>
            </div>
          </div>

          <button
            onClick={toggleDarkMode}
            className="p-1.5 rounded-lg text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white hover:bg-slate-200 dark:hover:bg-[#22272E] transition-colors cursor-pointer shrink-0"
            title={darkMode ? 'Switch to light mode' : 'Switch to dark mode'}
            aria-label="Toggle color theme"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </aside>
  );
};
