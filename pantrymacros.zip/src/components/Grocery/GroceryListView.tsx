import React, { useState } from 'react';
import {
  ShoppingCart,
  Plus,
  Trash2,
  Check,
  Copy,
  Printer,
  CheckCheck,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const GroceryListView: React.FC = () => {
  const {
    groceryList,
    addGroceryItem,
    toggleGroceryItem,
    deleteGroceryItem,
    clearCheckedGroceryItems,
  } = useApp();

  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('Produce');
  const [copyFeedback, setCopyFeedback] = useState(false);

  const uncheckedItems = groceryList.filter((g) => !g.checked);
  const checkedItems = groceryList.filter((g) => g.checked);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    addGroceryItem({
      name: newItemName.trim(),
      quantity: 1,
      unit: 'item',
      checked: false,
      category: newItemCategory,
      recipeSource: 'Manual',
    });

    setNewItemName('');
  };

  const handleCopyClipboard = () => {
    const lines = [
      '🛒 PantryMacros Grocery List',
      '--------------------------',
      ...uncheckedItems.map(
        (i) => `[ ] ${i.quantity ? `${i.quantity} ${i.unit} ` : ''}${i.name} ${i.recipeSource ? `(${i.recipeSource})` : ''}`
      ),
      ...(checkedItems.length > 0
        ? [
            '',
            'Already Purchased:',
            ...checkedItems.map((i) => `[x] ${i.name}`),
          ]
        : []),
    ];

    navigator.clipboard.writeText(lines.join('\n'));
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  // Group unchecked by category
  const categories = Array.from(new Set(groceryList.map((g) => g.category || 'General')));

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#14181C] dark:text-white">
            Smart Grocery List
          </h1>
          <p className="text-xs text-[#6E7781] dark:text-[#8B949E] mt-0.5">
            Auto-populated from missing recipe ingredients & custom staples. ({uncheckedItems.length} items remaining)
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyClipboard}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E4E8] dark:border-[#30363D] bg-white dark:bg-[#161B22] text-[#14181C] dark:text-white text-xs font-semibold hover:bg-slate-50 dark:hover:bg-[#21262D] transition-colors cursor-pointer"
          >
            {copyFeedback ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>Copy List</span>
              </>
            )}
          </button>

          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#E2E4E8] dark:border-[#30363D] bg-white dark:bg-[#161B22] text-[#14181C] dark:text-white text-xs font-semibold hover:bg-slate-50 dark:hover:bg-[#21262D] transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>

          {checkedItems.length > 0 && (
            <button
              onClick={clearCheckedGroceryItems}
              className="text-xs font-semibold text-[#A6243D] dark:text-rose-400 hover:underline px-2 cursor-pointer"
            >
              Clear Checked ({checkedItems.length})
            </button>
          )}
        </div>
      </div>

      {/* Quick Add Bar */}
      <form
        onSubmit={handleAddItem}
        className="flex items-center gap-2 p-2 rounded-2xl bg-white dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E]"
      >
        <input
          type="text"
          placeholder="Add an item (e.g. Olive Oil, Garlic, Avocado)..."
          value={newItemName}
          onChange={(e) => setNewItemName(e.target.value)}
          className="flex-1 px-3 py-1.5 text-xs bg-transparent text-[#14181C] dark:text-white placeholder-[#8B949E] focus:outline-hidden"
        />

        <select
          value={newItemCategory}
          onChange={(e) => setNewItemCategory(e.target.value)}
          className="text-xs px-2.5 py-1.5 rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-[#F6F8FA] dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
        >
          <option value="Produce">Produce</option>
          <option value="Meat & Poultry">Meat & Poultry</option>
          <option value="Dairy & Eggs">Dairy & Eggs</option>
          <option value="Pantry Staples">Pantry Staples</option>
          <option value="Baking & Spices">Baking & Spices</option>
        </select>

        <button
          type="submit"
          className="flex items-center gap-1 px-4 py-1.5 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-semibold transition-colors cursor-pointer shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Add</span>
        </button>
      </form>

      {/* Grocery Items List */}
      {groceryList.length === 0 ? (
        <div className="py-16 text-center text-xs text-[#6E7781] dark:text-[#8B949E] border border-dashed border-[#E2E4E8] dark:border-[#22272E] rounded-xl">
          Your grocery list is empty. Missing recipe ingredients will automatically appear here!
        </div>
      ) : (
        <div className="space-y-6">
          {/* Unchecked Pending Items */}
          <div className="border border-[#E2E4E8] dark:border-[#22272E] rounded-2xl bg-white dark:bg-[#161B22] overflow-hidden divide-y divide-[#EAECEF] dark:divide-[#21262D]">
            {uncheckedItems.length === 0 ? (
              <div className="p-8 text-center text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center justify-center gap-2">
                <CheckCheck className="w-4 h-4" />
                <span>All items checked off! Ready to cook.</span>
              </div>
            ) : (
              uncheckedItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-3.5 hover:bg-[#F6F8FA] dark:hover:bg-[#1C2128]/50 transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => toggleGroceryItem(item.id)}
                      className="w-5 h-5 rounded-md border border-slate-300 dark:border-slate-600 hover:border-[#14181C] dark:hover:border-white flex items-center justify-center transition-colors cursor-pointer"
                    />
                    <div>
                      <div className="text-xs font-semibold text-[#14181C] dark:text-white">
                        {item.name}
                      </div>
                      <div className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                        {item.category || 'General'}
                        {item.recipeSource && ` · From: ${item.recipeSource}`}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs tabular-nums font-semibold text-[#57606A] dark:text-[#8B949E]">
                      {item.quantity} {item.unit}
                    </span>
                    <button
                      onClick={() => deleteGroceryItem(item.id)}
                      className="p-1 rounded text-[#6E7781] hover:text-[#A6243D] opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                      title="Delete item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Checked / Purchased Items Section */}
          {checkedItems.length > 0 && (
            <div className="space-y-2">
              <div className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E] px-1">
                Completed & Purchased ({checkedItems.length})
              </div>
              <div className="border border-[#E2E4E8] dark:border-[#22272E] rounded-2xl bg-white/60 dark:bg-[#161B22]/60 overflow-hidden divide-y divide-[#EAECEF] dark:divide-[#21262D]">
                {checkedItems.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-3 opacity-60 hover:opacity-100 transition-opacity group"
                  >
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => toggleGroceryItem(item.id)}
                        className="w-5 h-5 rounded-md bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] flex items-center justify-center cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </button>
                      <span className="text-xs line-through text-[#6E7781] dark:text-[#8B949E]">
                        {item.name}
                      </span>
                    </div>

                    <button
                      onClick={() => deleteGroceryItem(item.id)}
                      className="p-1 text-[#6E7781] hover:text-[#A6243D]"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
