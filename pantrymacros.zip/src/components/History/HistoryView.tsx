import React, { useMemo, useState } from 'react';
import {
  TrendingUp,
  Scale,
  Calendar,
  Flame,
  CheckCircle2,
  AlertCircle,
  Plus,
  Trash2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatDatePretty, getTodayDateString } from '../../utils/nutrition';
import { TodayMealLogs } from '../Dashboard/TodayMealLogs';

export const HistoryView: React.FC = () => {
  const {
    meals,
    weightLogs,
    addWeightLog,
    deleteWeightLog,
    user,
    streakCount,
    selectedDate,
    setSelectedDate,
  } = useApp();

  const [newWeightInput, setNewWeightInput] = useState(String(user.weightKg || '78'));
  const [weightDateInput, setWeightDateInput] = useState(getTodayDateString());

  // Generate last 7 days metrics for trend chart
  const weeklyTrends = useMemo(() => {
    const days: Array<{
      dateStr: string;
      label: string;
      calories: number;
      protein: number;
      targetCal: number;
      targetPro: number;
    }> = [];

    const now = new Date();
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      const yr = d.getFullYear();
      const mo = String(d.getMonth() + 1).padStart(2, '0');
      const dy = String(d.getDate()).padStart(2, '0');
      const dateStr = `${yr}-${mo}-${dy}`;

      const dayMeals = meals.filter((m) => m.date === dateStr);
      const calories = dayMeals.reduce((sum, m) => sum + m.calories, 0);
      const protein = dayMeals.reduce((sum, m) => sum + m.protein, 0);

      const label = d.toLocaleDateString('en-US', { weekday: 'short' });
      days.push({
        dateStr,
        label,
        calories,
        protein,
        targetCal: user.targets.calories,
        targetPro: user.targets.protein,
      });
    }

    return days;
  }, [meals, user.targets]);

  const handleAddWeight = (e: React.FormEvent) => {
    e.preventDefault();
    const w = parseFloat(newWeightInput);
    if (!w || isNaN(w)) return;
    addWeightLog(w, weightDateInput);
  };

  // SVG weight chart coordinates
  const sortedWeights = useMemo(() => {
    return [...weightLogs].sort((a, b) => a.date.localeCompare(b.date));
  }, [weightLogs]);

  const minWeight = Math.min(...sortedWeights.map((w) => w.weightKg), user.weightKg) - 1.5;
  const maxWeight = Math.max(...sortedWeights.map((w) => w.weightKg), user.weightKg) + 1.5;
  const weightRange = Math.max(1, maxWeight - minWeight);

  const chartWidth = 500;
  const chartHeight = 160;

  const points = sortedWeights.map((item, idx) => {
    const x = (idx / Math.max(1, sortedWeights.length - 1)) * (chartWidth - 40) + 20;
    const y = chartHeight - ((item.weightKg - minWeight) / weightRange) * (chartHeight - 40) - 20;
    return { x, y, weight: item.weightKg, date: item.date };
  });

  const pathD = points.length > 0
    ? points.reduce((acc, pt, i) => (i === 0 ? `M ${pt.x},${pt.y}` : `${acc} L ${pt.x},${pt.y}`), '')
    : '';

  // Max calories for weekly bar chart scale
  const maxCal = Math.max(user.targets.calories * 1.2, ...weeklyTrends.map((t) => t.calories));

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#14181C] dark:text-white">
          Nutrition & Body Metrics Trends
        </h1>
        <p className="text-xs text-[#6E7781] dark:text-[#8B949E] mt-0.5">
          Weekly macro compliance, caloric consistency, and weigh-in progression.
        </p>
      </div>

      {/* Top 3 Scoreboard Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Streak & Consistency */}
        <div className="p-4 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22]">
          <div className="flex items-center justify-between text-xs text-[#57606A] dark:text-[#8B949E] mb-2 font-medium">
            <span>Tracking Streak</span>
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
          </div>
          <div className="text-3xl font-extrabold tabular-nums text-[#14181C] dark:text-white">
            {streakCount} <span className="text-sm font-semibold text-[#6E7781] dark:text-[#8B949E]">days</span>
          </div>
          <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E] mt-1">
            Logging daily drives predictable metabolic rate adaptation.
          </p>
        </div>

        {/* Current Weight */}
        <div className="p-4 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22]">
          <div className="flex items-center justify-between text-xs text-[#57606A] dark:text-[#8B949E] mb-2 font-medium">
            <span>Latest Weigh-in</span>
            <Scale className="w-4 h-4 text-[#3E7C6B]" />
          </div>
          <div className="text-3xl font-extrabold tabular-nums text-[#14181C] dark:text-white">
            {user.weightKg}{' '}
            <span className="text-sm font-semibold text-[#6E7781] dark:text-[#8B949E]">kg</span>
          </div>
          <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E] mt-1">
            Target goal: <strong className="capitalize">{user.goal.replace('_', ' ')}</strong>
          </p>
        </div>

        {/* 7-Day Protein Average */}
        <div className="p-4 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22]">
          <div className="flex items-center justify-between text-xs text-[#57606A] dark:text-[#8B949E] mb-2 font-medium">
            <span>7-Day Avg Protein</span>
            <span className="w-2.5 h-2.5 rounded-full bg-[#A6243D]" />
          </div>
          <div className="text-3xl font-extrabold tabular-nums text-[#A6243D] dark:text-rose-400">
            {Math.round(weeklyTrends.reduce((s, d) => s + d.protein, 0) / 7)}{' '}
            <span className="text-sm font-semibold text-[#6E7781] dark:text-[#8B949E]">g/day</span>
          </div>
          <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E] mt-1">
            Target: <strong className="tabular-nums">{user.targets.protein}g</strong> (
            {Math.round(
              ((weeklyTrends.reduce((s, d) => s + d.protein, 0) / 7) / (user.targets.protein || 1)) *
                100
            )}
            % compliance)
          </p>
        </div>
      </div>

      {/* Two Column Section: Weekly Trend Bar Chart & Weight Line Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Calories & Protein Bar Trend */}
        <div className="p-5 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#14181C] dark:text-white">
                Weekly Calorie & Protein Intake
              </h2>
              <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                Dashed line indicates your daily target ({user.targets.calories} kcal)
              </p>
            </div>
            <div className="flex items-center gap-3 text-[11px] font-semibold">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-[#14181C] dark:bg-white" />
                Calories
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-[#A6243D]" />
                Protein
              </span>
            </div>
          </div>

          {/* Bar Chart Container */}
          <div className="h-44 flex items-end justify-between gap-2 pt-6 relative border-b border-[#EAECEF] dark:border-[#21262D]">
            {/* Target line overlay */}
            <div
              className="absolute left-0 right-0 border-b border-dashed border-[#D4A017] z-10 pointer-events-none"
              style={{
                bottom: `${(user.targets.calories / maxCal) * 100}%`,
              }}
            />

            {weeklyTrends.map((day) => {
              const calHeight = Math.min(100, (day.calories / maxCal) * 100);
              const proHeight = Math.min(100, (day.protein / (user.targets.protein * 1.3)) * 100);
              const isSelected = day.dateStr === selectedDate;

              return (
                <div
                  key={day.dateStr}
                  onClick={() => setSelectedDate(day.dateStr)}
                  className={`flex-1 flex flex-col items-center gap-1 cursor-pointer transition-opacity ${
                    isSelected ? 'opacity-100' : 'opacity-85 hover:opacity-100'
                  }`}
                  title={`${day.label} (${day.dateStr}): ${day.calories} kcal, ${day.protein}g protein`}
                >
                  <div className="w-full flex items-end justify-center gap-1 h-36">
                    {/* Calories bar */}
                    <div
                      className={`w-3 rounded-t-md transition-all ${
                        isSelected
                          ? 'bg-[#14181C] dark:bg-white ring-2 ring-indigo-400'
                          : 'bg-[#14181C]/75 dark:bg-white/75'
                      }`}
                      style={{ height: `${Math.max(4, calHeight)}%` }}
                    />
                    {/* Protein bar */}
                    <div
                      className="w-3 rounded-t-md bg-[#A6243D] transition-all"
                      style={{ height: `${Math.max(4, proHeight)}%` }}
                    />
                  </div>
                  <span className={`text-[10px] font-semibold ${isSelected ? 'text-[#14181C] dark:text-white font-bold' : 'text-[#6E7781] dark:text-[#8B949E]'}`}>
                    {day.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Weight Tracking Chart */}
        <div className="p-5 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-[#14181C] dark:text-white">
                Weight Tracking Progression
              </h2>
              <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                Scale measurements mapped over time
              </p>
            </div>

            {/* Quick Log Weight Trigger Form */}
            <form onSubmit={handleAddWeight} className="flex items-center gap-1.5">
              <input
                type="number"
                step="0.1"
                placeholder="kg"
                value={newWeightInput}
                onChange={(e) => setNewWeightInput(e.target.value)}
                className="w-16 px-2 py-1 text-xs tabular-nums font-semibold rounded-lg border border-[#E1E4E8] dark:border-[#30363D] bg-[#F6F8FA] dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              />
              <button
                type="submit"
                className="px-3 py-1 rounded-lg bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-semibold cursor-pointer"
              >
                Log Weight
              </button>
            </form>
          </div>

          {/* SVG Line Chart */}
          <div className="w-full overflow-hidden">
            <svg
              className="w-full h-40 overflow-visible"
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            >
              {/* Subtle grid lines */}
              <line
                x1="20"
                y1="30"
                x2={chartWidth - 20}
                y2="30"
                stroke="currentColor"
                strokeDasharray="4 4"
                className="text-slate-200 dark:text-[#21262D]"
              />
              <line
                x1="20"
                y1={chartHeight / 2}
                x2={chartWidth - 20}
                y2={chartHeight / 2}
                stroke="currentColor"
                strokeDasharray="4 4"
                className="text-slate-200 dark:text-[#21262D]"
              />
              <line
                x1="20"
                y1={chartHeight - 30}
                x2={chartWidth - 20}
                y2={chartHeight - 30}
                stroke="currentColor"
                strokeDasharray="4 4"
                className="text-slate-200 dark:text-[#21262D]"
              />

              {/* Connected Line */}
              {pathD && (
                <path
                  d={pathD}
                  fill="none"
                  stroke="#3E7C6B"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}

              {/* Data points */}
              {points.map((pt, i) => (
                <g key={i}>
                  <circle
                    cx={pt.x}
                    cy={pt.y}
                    r="4"
                    fill="#3E7C6B"
                    className="hover:r-6 transition-all cursor-pointer"
                  />
                  <text
                    x={pt.x}
                    y={pt.y - 8}
                    textAnchor="middle"
                    className="text-[10px] tabular-nums font-semibold fill-[#14181C] dark:fill-white"
                  >
                    {pt.weight}
                  </text>
                </g>
              ))}
            </svg>
          </div>
        </div>
      </div>

      {/* Browsable Meal Log History by Day */}
      <div className="p-5 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] space-y-4">
        <div>
          <h2 className="text-sm font-bold text-[#14181C] dark:text-white">
            Daily Log Browser
          </h2>
          <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
            Inspect, edit, or delete logged foods for any historical date.
          </p>
        </div>

        <TodayMealLogs />
      </div>
    </div>
  );
};
