import React, { useState } from 'react';
import {
  Clock,
  Flame,
  CheckCircle2,
  AlertCircle,
  Plus,
  Minus,
  Utensils,
  BookOpen,
  Star,
  Bookmark,
  Share2,
  ShoppingCart,
  Check,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Recipe } from '../../types';

interface RecipeCardProps {
  recipe: Recipe;
  onOpenCookMode: (recipe: Recipe) => void;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onOpenCookMode }) => {
  const {
    cookRecipeAction,
    logRecipeMealAction,
    addMissingIngredientsToGrocery,
    toggleFavoriteRecipe,
    rateRecipe,
    updateRecipeNotes,
  } = useApp();

  const [servingsMultiplier, setServingsMultiplier] = useState(1);
  const [cookedSuccess, setCookedSuccess] = useState(false);
  const [loggedSuccess, setLoggedSuccess] = useState(false);
  const [groceryAddedCount, setGroceryAddedCount] = useState<number | null>(null);
  const [notesExpanded, setNotesExpanded] = useState(false);
  const [personalNoteText, setPersonalNoteText] = useState(recipe.personalNotes || '');
  const [stepsExpanded, setStepsExpanded] = useState(false);

  // Scaled nutrition
  const baseServings = recipe.servings || 1;
  const currentServings = Math.max(1, Math.round(baseServings * servingsMultiplier));
  const scale = servingsMultiplier;

  const totalCalories = Math.round(recipe.macrosPerServing.calories * scale);
  const totalProtein = Math.round(recipe.macrosPerServing.protein * scale);
  const totalCarbs = Math.round(recipe.macrosPerServing.carbs * scale);
  const totalFat = Math.round(recipe.macrosPerServing.fat * scale);

  const pantryIngredients = recipe.ingredients.filter((i) => i.fromPantry);
  const missingIngredients = recipe.ingredients.filter((i) => !i.fromPantry);

  const handleCook = () => {
    cookRecipeAction(recipe, servingsMultiplier);
    setCookedSuccess(true);
    setTimeout(() => setCookedSuccess(false), 3000);
  };

  const handleLog = () => {
    logRecipeMealAction(recipe, servingsMultiplier, 'dinner');
    setLoggedSuccess(true);
    setTimeout(() => setLoggedSuccess(false), 3000);
  };

  const handleAddToGrocery = () => {
    const count = addMissingIngredientsToGrocery(recipe);
    setGroceryAddedCount(count);
    setTimeout(() => setGroceryAddedCount(null), 3000);
  };

  const handleSaveNotes = () => {
    updateRecipeNotes(recipe.id, personalNoteText);
    setNotesExpanded(false);
  };

  return (
    <div className="relative flex flex-col justify-between rounded-2xl border border-[#D8DCE2] dark:border-[#282E37] bg-white dark:bg-[#161B22] p-5 shadow-xs transition-all hover:border-[#14181C]/40 dark:hover:border-white/40">
      {/* Top Meta & Actions */}
      <div>
        <div className="flex items-start justify-between gap-3 mb-2">
          {/* Times & Servings */}
          <div className="flex flex-wrap items-center gap-2 text-[11px] font-medium text-[#57606A] dark:text-[#8B949E]">
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3 text-[#D4A017]" />
              {recipe.prepTimeMinutes + recipe.cookTimeMinutes} min total
            </span>
            <span>·</span>
            <span>Prep: {recipe.prepTimeMinutes}m</span>
            <span>·</span>
            <span>Cook: {recipe.cookTimeMinutes}m</span>
          </div>

          {/* Favorite & Rating */}
          <div className="flex items-center gap-1.5 shrink-0">
            {/* Star Rating (1-5) */}
            <div className="flex items-center">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => rateRecipe(recipe.id, star)}
                  className="p-0.5 text-slate-300 dark:text-slate-600 hover:text-amber-400 dark:hover:text-amber-400 transition-colors cursor-pointer"
                  title={`Rate ${star} stars`}
                >
                  <Star
                    className={`w-3.5 h-3.5 ${
                      recipe.rating >= star
                        ? 'text-amber-400 fill-amber-400'
                        : ''
                    }`}
                  />
                </button>
              ))}
            </div>

            <button
              onClick={() => toggleFavoriteRecipe(recipe.id)}
              className="p-1 rounded-md text-[#6E7781] hover:text-[#A6243D] dark:hover:text-rose-400 transition-colors cursor-pointer ml-1"
              title={recipe.favorited ? 'Remove favorite' : 'Save to favorites'}
            >
              <Bookmark
                className={`w-4 h-4 ${
                  recipe.favorited ? 'text-[#A6243D] fill-[#A6243D] dark:text-rose-400 dark:fill-rose-400' : ''
                }`}
              />
            </button>
          </div>
        </div>

        {/* Recipe Title & Description */}
        <h3 className="text-base font-bold tracking-tight text-[#14181C] dark:text-white leading-snug">
          {recipe.title}
        </h3>
        <p className="text-xs text-[#57606A] dark:text-[#8B949E] mt-1 line-clamp-2 leading-relaxed">
          {recipe.description}
        </p>

        {/* Nutrition Breakdown Block */}
        <div className="my-4 p-3 rounded-xl bg-[#F6F8FA] dark:bg-[#0D1117] border border-[#E2E4E8] dark:border-[#21262D]">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-[#57606A] dark:text-[#8B949E]">
              Nutrition (per serving)
            </span>
            <span className="tabular-nums font-bold text-sm text-[#14181C] dark:text-white">
              {recipe.macrosPerServing.calories} kcal
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            {/* Protein */}
            <div className="p-2 rounded-lg bg-[#A6243D]/10 dark:bg-[#A6243D]/20 text-center">
              <span className="text-[10px] uppercase font-bold text-[#A6243D] dark:text-rose-400 block">
                Protein
              </span>
              <span className="tabular-nums text-sm font-extrabold text-[#14181C] dark:text-white">
                {recipe.macrosPerServing.protein}g
              </span>
            </div>

            {/* Carbs */}
            <div className="p-2 rounded-lg bg-[#D4A017]/10 dark:bg-[#D4A017]/20 text-center">
              <span className="text-[10px] uppercase font-bold text-[#D4A017] dark:text-amber-400 block">
                Carbs
              </span>
              <span className="tabular-nums text-sm font-extrabold text-[#14181C] dark:text-white">
                {recipe.macrosPerServing.carbs}g
              </span>
            </div>

            {/* Fat */}
            <div className="p-2 rounded-lg bg-[#3E7C6B]/10 dark:bg-[#3E7C6B]/20 text-center">
              <span className="text-[10px] uppercase font-bold text-[#3E7C6B] dark:text-teal-400 block">
                Fat
              </span>
              <span className="tabular-nums text-sm font-extrabold text-[#14181C] dark:text-white">
                {recipe.macrosPerServing.fat}g
              </span>
            </div>
          </div>
        </div>

        {/* Servings Adjuster */}
        <div className="flex items-center justify-between py-2 border-y border-[#EAECEF] dark:border-[#21262D] text-xs">
          <span className="font-medium text-[#57606A] dark:text-[#8B949E]">Recipe Servings:</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setServingsMultiplier((prev) => Math.max(0.5, prev - 0.5))}
              className="w-6 h-6 rounded-md border border-[#D0D7DE] dark:border-[#30363D] flex items-center justify-center hover:bg-slate-100 dark:hover:bg-[#21262D] transition-colors cursor-pointer text-[#14181C] dark:text-white"
              title="Decrease servings"
            >
              <Minus className="w-3 h-3" />
            </button>
            <span className="tabular-nums font-bold text-xs w-6 text-center text-[#14181C] dark:text-white">
              {currentServings}
            </span>
            <button
              onClick={() => setServingsMultiplier((prev) => prev + 0.5)}
              className="w-6 h-6 rounded-md border border-[#D0D7DE] dark:border-[#30363D] flex items-center justify-center hover:bg-slate-100 dark:hover:bg-[#21262D] transition-colors cursor-pointer text-[#14181C] dark:text-white"
              title="Increase servings"
            >
              <Plus className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Ingredients Split: Have (Pantry) vs Need to Buy */}
        <div className="py-3 space-y-3">
          {/* Have from Pantry */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#3E7C6B] dark:text-teal-400 mb-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>In Your Pantry ({pantryIngredients.length})</span>
            </div>
            <ul className="space-y-1 text-xs text-[#14181C] dark:text-white pl-5 list-disc marker:text-[#3E7C6B]">
              {pantryIngredients.map((ing, i) => (
                <li key={i} className="leading-snug">
                  <strong className="tabular-nums">
                    {Math.round(ing.quantity * servingsMultiplier * 10) / 10} {ing.unit}
                  </strong>{' '}
                  {ing.name}
                </li>
              ))}
            </ul>
          </div>

          {/* Need to Buy / Missing */}
          {missingIngredients.length > 0 && (
            <div className="pt-2 border-t border-[#EAECEF] dark:border-[#21262D]">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-[#D4A017] dark:text-amber-400">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Need to Buy ({missingIngredients.length})</span>
                </div>
                <button
                  onClick={handleAddToGrocery}
                  className="text-[11px] font-semibold text-[#14181C] dark:text-white hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <ShoppingCart className="w-3 h-3" />
                  {groceryAddedCount ? 'Added!' : '+ To Grocery List'}
                </button>
              </div>

              <ul className="space-y-1.5 text-xs pl-5 list-disc marker:text-[#D4A017]">
                {missingIngredients.map((ing, i) => (
                  <li key={i} className="leading-snug text-[#14181C] dark:text-white">
                    <span>
                      <strong className="tabular-nums">
                        {Math.round(ing.quantity * servingsMultiplier * 10) / 10} {ing.unit}
                      </strong>{' '}
                      {ing.name}
                    </span>
                    {ing.substitution && (
                      <div className="text-[11px] text-[#6E7781] dark:text-[#8B949E] italic mt-0.5">
                        Pantry sub: {ing.substitution}
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {/* Instructions Toggle or Teaser */}
        <div className="pt-2 border-t border-[#EAECEF] dark:border-[#21262D]">
          <button
            onClick={() => setStepsExpanded(!stepsExpanded)}
            className="w-full flex items-center justify-between text-xs font-semibold text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white py-1 cursor-pointer"
          >
            <span>Cooking Steps ({recipe.instructions?.length || 0})</span>
            {stepsExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {stepsExpanded && (
            <ol className="mt-2 space-y-2 text-xs text-[#14181C] dark:text-white list-decimal pl-4">
              {recipe.instructions.map((inst, i) => (
                <li key={i} className="pl-1 leading-relaxed">
                  {inst.text}
                  {inst.durationMinutes && (
                    <span className="text-[10px] text-[#6E7781] dark:text-[#8B949E] ml-1">
                      (~{inst.durationMinutes}m)
                    </span>
                  )}
                </li>
              ))}
            </ol>
          )}
        </div>

        {/* Personal Notes Section */}
        {notesExpanded ? (
          <div className="mt-3 p-2.5 rounded-xl bg-[#F6F8FA] dark:bg-[#0D1117] border border-[#E2E4E8] dark:border-[#21262D] space-y-2">
            <textarea
              rows={2}
              value={personalNoteText}
              onChange={(e) => setPersonalNoteText(e.target.value)}
              placeholder="Add your cooking notes, tweaks, seasoning tips..."
              className="w-full text-xs p-2 bg-white dark:bg-[#161B22] rounded-lg border border-[#E1E4E8] dark:border-[#30363D] text-[#14181C] dark:text-white focus:outline-hidden"
            />
            <div className="flex justify-end gap-1.5">
              <button
                onClick={() => setNotesExpanded(false)}
                className="px-2 py-1 text-[11px] text-[#6E7781]"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveNotes}
                className="px-3 py-1 text-[11px] font-semibold bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] rounded-md"
              >
                Save Note
              </button>
            </div>
          </div>
        ) : (
          recipe.personalNotes && (
            <div
              onClick={() => setNotesExpanded(true)}
              className="mt-2 text-[11px] text-[#6E7781] dark:text-[#8B949E] italic bg-[#F6F8FA] dark:bg-[#0D1117] p-2 rounded-lg cursor-pointer hover:bg-slate-200 dark:hover:bg-[#21262D]"
            >
              <strong>My Note:</strong> &ldquo;{recipe.personalNotes}&rdquo;
            </div>
          )
        )}
      </div>

      {/* Card Action Buttons (One-tap Cook This, Log Meal, Cook Mode) */}
      <div className="mt-4 pt-3 border-t border-[#EAECEF] dark:border-[#21262D] space-y-2">
        <div className="grid grid-cols-2 gap-2">
          {/* One-Tap Cook This */}
          <button
            onClick={handleCook}
            disabled={cookedSuccess}
            className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              cookedSuccess
                ? 'bg-emerald-600 text-white'
                : 'border border-[#D8DCE2] dark:border-[#30363D] text-[#14181C] dark:text-white hover:bg-slate-100 dark:hover:bg-[#21262D]'
            }`}
          >
            {cookedSuccess ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Pantry Decremented!</span>
              </>
            ) : (
              <>
                <Utensils className="w-3.5 h-3.5 text-[#3E7C6B]" />
                <span>Cook This</span>
              </>
            )}
          </button>

          {/* One-Tap Log This Meal */}
          <button
            onClick={handleLog}
            disabled={loggedSuccess}
            className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              loggedSuccess
                ? 'bg-emerald-600 text-white'
                : 'border border-[#D8DCE2] dark:border-[#30363D] text-[#14181C] dark:text-white hover:bg-slate-100 dark:hover:bg-[#21262D]'
            }`}
          >
            {loggedSuccess ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>Logged to Today!</span>
              </>
            ) : (
              <>
                <Flame className="w-3.5 h-3.5 text-[#A6243D]" />
                <span>Log This Meal</span>
              </>
            )}
          </button>
        </div>

        {/* Cook Mode Fullscreen Step-by-Step */}
        <button
          onClick={() => onOpenCookMode(recipe)}
          className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-bold transition-colors cursor-pointer shadow-xs"
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Launch Step-by-Step Cook Mode</span>
        </button>
      </div>
    </div>
  );
};
