import React, { useState } from 'react';
import {
  X,
  Calendar,
  Sparkles,
  ShoppingCart,
  Check,
  Clock,
  Flame,
  ArrowRight,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { DayDinnerPlan } from '../../types';

interface WeekPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WeekPlanModal: React.FC<WeekPlanModalProps> = ({ isOpen, onClose }) => {
  const { pantry, user, addGroceryItem } = useApp();

  const [days, setDays] = useState<3 | 5 | 7>(5);
  const [isGenerating, setIsGenerating] = useState(false);
  const [plan, setPlan] = useState<DayDinnerPlan[] | null>(null);
  const [masterGroceryList, setMasterGroceryList] = useState<string[]>([]);
  const [groceriesAdded, setGroceriesAdded] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGeneratePlan = async () => {
    setIsGenerating(true);
    setErrorMessage(null);
    setGroceriesAdded(false);

    try {
      const response = await fetch('/api/recipes/plan-week', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          days,
          pantryItems: pantry,
          dailyTargetDinnerMacros: {
            calories: Math.round(user.targets.calories * 0.35),
            protein: Math.round(user.targets.protein * 0.35),
            carbs: Math.round(user.targets.carbs * 0.35),
            fat: Math.round(user.targets.fat * 0.35),
          },
          preferences: user.dietaryPreferences,
          allergies: user.allergies,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate weekly dinner plan');
      }

      const data = await response.json();
      setPlan(data.plan || []);
      setMasterGroceryList(data.masterGroceryList || data.additionalGroceries || []);
    } catch (err: any) {
      console.error('Plan week error:', err);
      setErrorMessage(err?.message || 'Error creating weekly plan.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAddAllToGroceries = () => {
    if (masterGroceryList.length === 0) return;

    masterGroceryList.forEach((item) => {
      addGroceryItem({
        name: item,
        quantity: 1,
        unit: 'item',
        checked: false,
        recipeSource: `Week Plan (${days} days)`,
        category: 'Weekly Plan Grocery',
      });
    });

    setGroceriesAdded(true);
    setTimeout(() => setGroceriesAdded(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="w-full max-w-4xl bg-white dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#EAECEF] dark:border-[#21262D]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] flex items-center justify-center">
              <Calendar className="w-4 h-4 text-[#D4A017]" />
            </div>
            <div>
              <h2 className="text-base font-bold text-[#14181C] dark:text-white">
                Plan My Week Dinner Strategy
              </h2>
              <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                Generate an optimized dinner schedule using current pantry items with minimal grocery purchases.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-[#6E7781] hover:text-[#14181C] dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#22272E] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Days duration selector */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl bg-[#F6F8FA] dark:bg-[#0D1117] border border-[#E2E4E8] dark:border-[#21262D]">
            <div>
              <div className="text-xs font-bold text-[#14181C] dark:text-white">
                Choose Plan Duration
              </div>
              <div className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                Balances daily dinner macros according to your targets (~{Math.round(user.targets.calories * 0.35)} kcal/dinner).
              </div>
            </div>

            <div className="flex items-center gap-2">
              {[3, 5, 7].map((num) => (
                <button
                  key={num}
                  type="button"
                  onClick={() => setDays(num as any)}
                  className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                    days === num
                      ? 'bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] shadow-xs'
                      : 'border border-[#E2E4E8] dark:border-[#30363D] text-[#57606A] dark:text-[#8B949E] hover:bg-slate-200 dark:hover:bg-[#21262D]'
                  }`}
                >
                  {num} Days
                </button>
              ))}

              <button
                type="button"
                onClick={handleGeneratePlan}
                disabled={isGenerating}
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-bold transition-colors cursor-pointer shadow-xs disabled:opacity-40"
              >
                {isGenerating ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    <span>Planning...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
                    <span>Generate Plan</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 text-xs rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-300 border border-red-200">
              {errorMessage}
            </div>
          )}

          {/* Results Display */}
          {plan ? (
            <div className="space-y-6">
              {/* Day Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {plan.map((dayPlan, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs text-[#6E7781] dark:text-[#8B949E] mb-1">
                        <span className="font-semibold text-[#14181C] dark:text-white">
                          {dayPlan.day || `Day ${idx + 1}`}
                        </span>
                        {dayPlan.prepTimeMinutes && (
                          <span className="flex items-center gap-1 text-[11px]">
                            <Clock className="w-3 h-3 text-[#D4A017]" />
                            {dayPlan.prepTimeMinutes}m
                          </span>
                        )}
                      </div>

                      <h4 className="text-xs font-bold text-[#14181C] dark:text-white leading-snug">
                        {dayPlan.recipeTitle}
                      </h4>
                      <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E] mt-1 line-clamp-2">
                        {dayPlan.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#EAECEF] dark:border-[#21262D]">
                      <div className="flex items-center justify-between text-[11px] font-semibold tabular-nums text-[#14181C] dark:text-white mb-2">
                        <span>{dayPlan.macros?.calories || 520} kcal</span>
                        <div className="flex gap-2 text-[10px]">
                          <span className="text-[#A6243D] dark:text-rose-400">
                            {dayPlan.macros?.protein || 42}g P
                          </span>
                          <span className="text-[#D4A017] dark:text-amber-400">
                            {dayPlan.macros?.carbs || 45}g C
                          </span>
                          <span className="text-[#3E7C6B] dark:text-teal-400">
                            {dayPlan.macros?.fat || 16}g F
                          </span>
                        </div>
                      </div>

                      {dayPlan.extraGroceriesNeeded && dayPlan.extraGroceriesNeeded.length > 0 && (
                        <div className="text-[10px] text-[#6E7781] dark:text-[#8B949E]">
                          Needs: {dayPlan.extraGroceriesNeeded.join(', ')}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Master Combined Grocery List */}
              {masterGroceryList.length > 0 && (
                <div className="p-4 rounded-xl border border-[#D4A017]/30 bg-[#D4A017]/5 dark:bg-[#D4A017]/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <div className="text-xs font-bold text-[#14181C] dark:text-white flex items-center gap-1.5">
                      <ShoppingCart className="w-3.5 h-3.5 text-[#D4A017]" />
                      <span>Missing Ingredients Across Week ({masterGroceryList.length})</span>
                    </div>
                    <div className="text-[11px] text-[#6E7781] dark:text-[#8B949E] mt-0.5 max-w-xl">
                      {masterGroceryList.join(', ')}
                    </div>
                  </div>

                  <button
                    onClick={handleAddAllToGroceries}
                    disabled={groceriesAdded}
                    className="px-4 py-2 rounded-lg bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-semibold transition-colors cursor-pointer shrink-0"
                  >
                    {groceriesAdded ? (
                      <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                        <Check className="w-3.5 h-3.5" /> Added to Grocery List!
                      </span>
                    ) : (
                      <span>+ Add All to Grocery List</span>
                    )}
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="py-16 text-center text-xs text-[#6E7781] dark:text-[#8B949E] border border-dashed border-[#E2E4E8] dark:border-[#22272E] rounded-xl">
              Click &quot;Generate Plan&quot; to build a personalized {days}-day dinner schedule maximizing your current pantry items.
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-[#EAECEF] dark:border-[#21262D] flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
