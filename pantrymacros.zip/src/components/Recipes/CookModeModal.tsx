import React, { useEffect, useState } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Clock,
  Utensils,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Recipe } from '../../types';

interface CookModeModalProps {
  recipe: Recipe | null;
  onClose: () => void;
}

export const CookModeModal: React.FC<CookModeModalProps> = ({ recipe, onClose }) => {
  if (!recipe) return null;

  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const steps = recipe.instructions || [];
  const currentStep = steps[currentStepIndex];

  // Timer state for current step
  const initialSeconds = (currentStep?.durationMinutes || 3) * 60;
  const [secondsLeft, setSecondsLeft] = useState(initialSeconds);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Reset timer whenever step changes
  useEffect(() => {
    const sec = (currentStep?.durationMinutes || 3) * 60;
    setSecondsLeft(sec);
    setIsTimerRunning(false);
  }, [currentStepIndex, currentStep]);

  // Timer interval countdown
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && secondsLeft > 0) {
      interval = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            clearInterval(interval!);
            setIsTimerRunning(false);
            // Play web audio chime if sound enabled
            if (soundEnabled) {
              playTimerBeep();
            }
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, secondsLeft, soundEnabled]);

  // Audio synthesis for timer completion
  const playTimerBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.6);
    } catch (e) {
      console.warn('AudioContext not available or blocked', e);
    }
  };

  // Keyboard navigation: Left/Right Arrow for Prev/Next, Spacebar for Timer
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'KeyN') {
        if (currentStepIndex < steps.length - 1) {
          setCurrentStepIndex((prev) => prev + 1);
        }
      } else if (e.key === 'ArrowLeft' || e.key === 'KeyP') {
        if (currentStepIndex > 0) {
          setCurrentStepIndex((prev) => prev - 1);
        }
      } else if (e.code === 'Space') {
        e.preventDefault();
        setIsTimerRunning((prev) => !prev);
      } else if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentStepIndex, steps.length, onClose]);

  const formatTimer = (totalSec: number) => {
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const isCompleted = currentStepIndex === steps.length - 1;

  return (
    <div className="fixed inset-0 z-50 bg-[#14181C] text-white flex flex-col justify-between p-6 md:p-12 animate-in fade-in duration-200">
      {/* Top Bar */}
      <div className="flex items-center justify-between border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <div className="px-2.5 py-1 rounded-md bg-[#A6243D] text-white font-bold text-xs">
            Cook Mode
          </div>
          <div>
            <h1 className="text-base md:text-lg font-bold truncate max-w-xl">
              {recipe.title}
            </h1>
            <p className="text-xs text-white/60">
              Step {currentStepIndex + 1} of {steps.length}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition-colors cursor-pointer"
            title={soundEnabled ? 'Mute timer chime' : 'Enable timer chime'}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold text-xs transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
            <span>Exit (Esc)</span>
          </button>
        </div>
      </div>

      {/* Main Center Stage: One Step Visible at a Time */}
      <div className="flex-1 flex flex-col md:flex-row items-center justify-center gap-8 md:gap-16 py-8 max-w-5xl mx-auto w-full">
        {/* Step Text & Progress */}
        <div className="flex-1 space-y-6 text-center md:text-left">
          <div className="text-sm font-semibold tracking-wider uppercase text-[#D4A017]">
            Instruction #{currentStepIndex + 1}
          </div>

          <div className="text-2xl md:text-3xl lg:text-4xl font-semibold leading-relaxed tracking-tight text-white/95">
            {currentStep?.text || 'Review your ingredients and begin prep.'}
          </div>

          <div className="text-xs text-white/50 flex items-center gap-4 justify-center md:justify-start">
            <span>Use Left/Right arrows to navigate steps</span>
            <span>·</span>
            <span>Spacebar to toggle step timer</span>
          </div>
        </div>

        {/* Step Timer Display */}
        <div className="w-72 shrink-0 p-6 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex flex-col items-center text-center">
          <div className="flex items-center gap-1.5 text-xs text-white/70 mb-2">
            <Clock className="w-4 h-4 text-[#D4A017]" />
            <span>Step Countdown Timer</span>
          </div>

          {/* Time Tabular Display */}
          <div className="text-5xl font-extrabold tabular-nums tracking-tight font-mono my-3 text-white">
            {formatTimer(secondsLeft)}
          </div>

          {/* Timer Controls */}
          <div className="flex items-center gap-2 mt-2">
            <button
              onClick={() => setIsTimerRunning(!isTimerRunning)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white text-[#14181C] font-bold text-xs hover:bg-white/90 transition-colors cursor-pointer shadow-md"
            >
              {isTimerRunning ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start</span>
                </>
              )}
            </button>

            <button
              onClick={() => {
                setIsTimerRunning(false);
                setSecondsLeft((currentStep?.durationMinutes || 3) * 60);
              }}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              title="Reset Timer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Step Navigation Bar */}
      <div className="flex items-center justify-between border-t border-white/10 pt-4">
        <button
          onClick={() => setCurrentStepIndex((prev) => Math.max(0, prev - 1))}
          disabled={currentStepIndex === 0}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-30 disabled:cursor-not-allowed font-semibold text-xs transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous Step</span>
        </button>

        {/* Step dots indicator */}
        <div className="flex items-center gap-2">
          {steps.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentStepIndex(idx)}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                idx === currentStepIndex
                  ? 'w-6 bg-[#A6243D]'
                  : idx < currentStepIndex
                  ? 'w-2 bg-emerald-500'
                  : 'w-2 bg-white/20 hover:bg-white/40'
              }`}
              title={`Jump to step ${idx + 1}`}
            />
          ))}
        </div>

        {isCompleted ? (
          <button
            onClick={onClose}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-lg"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Finish Cooking</span>
          </button>
        ) : (
          <button
            onClick={() => setCurrentStepIndex((prev) => Math.min(steps.length - 1, prev + 1))}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white text-[#14181C] hover:bg-white/90 font-bold text-xs transition-colors cursor-pointer shadow-lg"
          >
            <span>Next Step</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
