import React, { useMemo, useState } from 'react';
import {
  Sparkles,
  Calendar,
  Clock,
  Filter,
  Flame,
  Bookmark,
  Search,
  RefreshCw,
  SlidersHorizontal,
  Plus,
  AlertTriangle,
  History,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { Recipe } from '../../types';
import { RecipeCard } from './RecipeCard';
import { WeekPlanModal } from './WeekPlanModal';
import { CookModeModal } from './CookModeModal';
import { getDaysUntilExpiration, getUrgencyStatus } from '../../utils/nutrition';

interface RecipeEngineViewProps {
  onOpenScanner: () => void;
}

export const RecipeEngineView: React.FC<RecipeEngineViewProps> = ({ onOpenScanner }) => {
  const {
    pantry,
    user,
    remainingMacros,
    recipes,
    saveRecipe,
    cookRecipeAction,
    logRecipeMealAction,
  } = useApp();

  const [isGenerating, setIsGenerating] = useState(false);
  const [customPrompt, setCustomPrompt] = useState('');
  const [activeTab, setActiveTab] = useState<'suggestions' | 'library' | 'history'>('suggestions');
  const [isWeekPlanOpen, setIsWeekPlanOpen] = useState(false);
  const [cookModeRecipe, setCookModeRecipe] = useState<Recipe | null>(null);

  // Suggestions state (active 3 recipes)
  const [suggestedRecipes, setSuggestedRecipes] = useState<Recipe[]>(() => {
    // Default to the first 3 recipes in saved recipes or starters
    return recipes.slice(0, 3);
  });
  const [generationError, setGenerationError] = useState<string | null>(null);

  // Library filters
  const [librarySearch, setLibrarySearch] = useState('');
  const [onlyFavorites, setOnlyFavorites] = useState(false);

  // Urgent expiring items
  const expiringPantryItems = useMemo(() => {
    return pantry
      .filter((p) => {
        const status = getUrgencyStatus(getDaysUntilExpiration(p.expirationDate));
        return status === 'use_soon' || status === 'expired';
      })
      .map((p) => p.name);
  }, [pantry]);

  // Generate 3 fresh suggestions matching remaining macros
  const handleGenerateSuggestions = async () => {
    setIsGenerating(true);
    setGenerationError(null);

    try {
      const response = await fetch('/api/recipes/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pantryItems: pantry,
          remainingMacros,
          preferences: user.dietaryPreferences,
          allergies: user.allergies,
          cookingSkill: user.cookingSkill,
          timeBudget: user.timeBudget,
          householdSize: user.householdSize,
          expiringItems: expiringPantryItems,
          customPrompt: customPrompt.trim() || undefined,
        }),
      });

      if (!response.ok) {
        const errJson = await response.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to generate recipes');
      }

      const data = await response.json();
      const newRecipes: Recipe[] = data.recipes || [];

      if (newRecipes.length === 0) {
        throw new Error('No recipes returned. Try relaxing dietary filters or adding more pantry items.');
      }

      setSuggestedRecipes(newRecipes);
      // Auto-save every generated recipe into recipe library as required
      newRecipes.forEach((r) => saveRecipe(r));
    } catch (err: any) {
      console.error('Recipe gen error:', err);
      setGenerationError(err?.message || 'Error communicating with recipe server.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Filtered Library recipes
  const filteredLibrary = useMemo(() => {
    return recipes.filter((r) => {
      if (onlyFavorites && !r.favorited) return false;
      if (librarySearch && !r.title.toLowerCase().includes(librarySearch.toLowerCase()))
        return false;
      return true;
    });
  }, [recipes, onlyFavorites, librarySearch]);

  // Recently cooked recipes
  const recentlyCooked = useMemo(() => {
    return recipes
      .filter((r) => Boolean(r.lastCookedDate))
      .sort((a, b) => (b.lastCookedDate || '').localeCompare(a.lastCookedDate || ''));
  }, [recipes]);

  return (
    <div className="space-y-6">
      {/* Top Banner & Generation Controls */}
      <div className="flex flex-col xl:flex-row items-start xl:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-[#14181C] dark:text-white">
            AI Recipe Engine
          </h1>
          <p className="text-xs text-[#6E7781] dark:text-[#8B949E] mt-0.5">
            Generates 3 recipes calibrated to fit your remaining {remainingMacros.calories} kcal (
            <strong className="text-[#A6243D] dark:text-rose-400 font-semibold tabular-nums">
              {remainingMacros.protein}g P
            </strong>
            ,{' '}
            <strong className="text-[#D4A017] dark:text-amber-400 font-semibold tabular-nums">
              {remainingMacros.carbs}g C
            </strong>
            ,{' '}
            <strong className="text-[#3E7C6B] dark:text-teal-400 font-semibold tabular-nums">
              {remainingMacros.fat}g F
            </strong>
            ).
          </p>
        </div>

        {/* View Switcher Tabs & Plan Week Button */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Segmented Tab */}
          <div className="flex items-center gap-1 p-1 bg-[#F2F4F7] dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E] rounded-xl text-xs">
            <button
              onClick={() => setActiveTab('suggestions')}
              className={`px-3 py-1 font-semibold rounded-lg transition-colors cursor-pointer ${
                activeTab === 'suggestions'
                  ? 'bg-white dark:bg-[#21262D] text-[#14181C] dark:text-white shadow-xs'
                  : 'text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white'
              }`}
            >
              Today&apos;s 3 Matches
            </button>
            <button
              onClick={() => setActiveTab('library')}
              className={`px-3 py-1 font-semibold rounded-lg transition-colors cursor-pointer ${
                activeTab === 'library'
                  ? 'bg-white dark:bg-[#21262D] text-[#14181C] dark:text-white shadow-xs'
                  : 'text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white'
              }`}
            >
              Saved Library ({recipes.length})
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`px-3 py-1 font-semibold rounded-lg transition-colors cursor-pointer ${
                activeTab === 'history'
                  ? 'bg-white dark:bg-[#21262D] text-[#14181C] dark:text-white shadow-xs'
                  : 'text-[#57606A] dark:text-[#8B949E] hover:text-[#14181C] dark:hover:text-white'
              }`}
            >
              Recently Cooked
            </button>
          </div>

          {/* Plan My Week Action */}
          <button
            onClick={() => setIsWeekPlanOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl border border-[#D4A017]/40 bg-[#D4A017]/10 hover:bg-[#D4A017]/20 text-[#14181C] dark:text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            <Calendar className="w-3.5 h-3.5 text-[#D4A017]" />
            <span>Plan My Week</span>
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      {activeTab === 'suggestions' && (
        <div className="space-y-6">
          {/* Generator Command Bar */}
          <div className="p-4 rounded-2xl bg-white dark:bg-[#161B22] border border-[#E2E4E8] dark:border-[#22272E] space-y-3">
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder="Custom wish: e.g., 'high-volume soup', 'crispy spicy skillet', 'low carb post-workout'..."
                  value={customPrompt}
                  onChange={(e) => setCustomPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleGenerateSuggestions();
                  }}
                  className="w-full px-3.5 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-[#F6F8FA] dark:bg-[#0D1117] text-[#14181C] dark:text-white placeholder-[#8B949E] focus:outline-hidden focus:border-[#14181C] dark:focus:border-white"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleGenerateSuggestions}
                  disabled={isGenerating}
                  className="flex items-center justify-center gap-2 px-5 py-2 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-bold transition-colors cursor-pointer shadow-xs disabled:opacity-40"
                >
                  {isGenerating ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      <span>Calibrating Recipes...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-[#D4A017]" />
                      <span>Generate 3 Recipes</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Leftover awareness hint */}
            {expiringPantryItems.length > 0 && (
              <div className="flex items-center gap-2 text-[11px] text-[#D4A017] dark:text-amber-400 font-medium">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>
                  Leftover-aware engine: prioritizing items expiring soon ({expiringPantryItems.join(', ')})
                </span>
              </div>
            )}
          </div>

          {generationError && (
            <div className="p-3 text-xs rounded-xl bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-300 border border-red-200">
              {generationError}
            </div>
          )}

          {/* DESKTOP 3-COLUMN SIDE-BY-SIDE RECIPE COMPARISON GRID */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 items-stretch">
            {suggestedRecipes.map((recipe) => (
              <RecipeCard
                key={recipe.id}
                recipe={recipe}
                onOpenCookMode={(r) => setCookModeRecipe(r)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Library Tab */}
      {activeTab === 'library' && (
        <div className="space-y-4">
          {/* Library Search & Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative flex-1 max-w-md w-full">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#6E7781]" />
              <input
                type="text"
                placeholder="Search recipe library..."
                value={librarySearch}
                onChange={(e) => setLibrarySearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#161B22] text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            <button
              onClick={() => setOnlyFavorites(!onlyFavorites)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-semibold transition-colors cursor-pointer ${
                onlyFavorites
                  ? 'border-[#A6243D] bg-[#A6243D]/10 text-[#A6243D] dark:text-rose-400'
                  : 'border-[#E2E4E8] dark:border-[#30363D] text-[#57606A] dark:text-[#8B949E]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
              <span>Favorites Only</span>
            </button>
          </div>

          {filteredLibrary.length === 0 ? (
            <div className="py-16 text-center text-xs text-[#6E7781] dark:text-[#8B949E] border border-dashed border-[#E2E4E8] dark:border-[#22272E] rounded-xl">
              No saved recipes match the search criteria.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 items-stretch">
              {filteredLibrary.map((recipe) => (
                <RecipeCard
                  key={recipe.id}
                  recipe={recipe}
                  onOpenCookMode={(r) => setCookModeRecipe(r)}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* History & Repeat Meal Shortcuts */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="text-xs text-[#6E7781] dark:text-[#8B949E]">
            Recently cooked meals. Skip the scan and repeat with 1 click:
          </div>

          {recentlyCooked.length === 0 ? (
            <div className="py-16 text-center text-xs text-[#6E7781] dark:text-[#8B949E] border border-dashed border-[#E2E4E8] dark:border-[#22272E] rounded-xl">
              No cooked meals recorded yet. Click &quot;Cook This&quot; on any recipe card to log your first dish!
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 items-stretch">
              {recentlyCooked.map((recipe) => (
                <RecipeCard
                  key={recipe.id}
                  recipe={recipe}
                  onOpenCookMode={(r) => setCookModeRecipe(r)}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Week Plan Modal */}
      {isWeekPlanOpen && (
        <WeekPlanModal isOpen={isWeekPlanOpen} onClose={() => setIsWeekPlanOpen(false)} />
      )}

      {/* Cook Mode Fullscreen */}
      {cookModeRecipe && (
        <CookModeModal recipe={cookModeRecipe} onClose={() => setCookModeRecipe(null)} />
      )}
    </div>
  );
};
