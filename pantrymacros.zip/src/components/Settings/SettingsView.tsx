import React, { useState } from 'react';
import {
  Save,
  Calculator,
  RotateCcw,
  Leaf,
  DollarSign,
  User,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import {
  ActivityLevel,
  CookingSkill,
  FitnessGoal,
  TimeBudget,
  UserProfile,
} from '../../types';
import { calculateSuggestedMacros } from '../../utils/nutrition';

const DIETARY_OPTIONS = [
  'none',
  'high-protein',
  'vegan',
  'vegetarian',
  'keto',
  'gluten-free',
  'dairy-free',
  'halal',
  'kosher',
];

export const SettingsView: React.FC = () => {
  const { user, updateUser, foodWasteStats, darkMode, toggleDarkMode } = useApp();

  const [formData, setFormData] = useState<UserProfile>(user);
  const [newAllergy, setNewAllergy] = useState('');
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleInputChange = (field: keyof UserProfile, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleMacroChange = (macro: keyof UserProfile['targets'], value: string) => {
    const num = parseInt(value) || 0;
    setFormData((prev) => ({
      ...prev,
      targets: {
        ...prev.targets,
        [macro]: num,
      },
    }));
  };

  const handleRecalculateAutoTargets = () => {
    const suggested = calculateSuggestedMacros({
      age: formData.age,
      sex: formData.sex,
      heightCm: formData.heightCm,
      weightKg: formData.weightKg,
      activityLevel: formData.activityLevel,
      goal: formData.goal,
    });
    setFormData((prev) => ({ ...prev, targets: suggested }));
  };

  const toggleDietaryPref = (pref: string) => {
    if (pref === 'none') {
      setFormData((prev) => ({ ...prev, dietaryPreferences: ['none'] }));
      return;
    }
    const filtered = formData.dietaryPreferences.filter((p) => p !== 'none');
    if (filtered.includes(pref)) {
      setFormData((prev) => ({
        ...prev,
        dietaryPreferences: filtered.filter((p) => p !== pref),
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        dietaryPreferences: [...filtered, pref],
      }));
    }
  };

  const handleAddAllergy = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAllergy.trim()) return;
    if (!formData.allergies.includes(newAllergy.trim())) {
      setFormData((prev) => ({
        ...prev,
        allergies: [...prev.allergies, newAllergy.trim()],
      }));
    }
    setNewAllergy('');
  };

  const handleRemoveAllergy = (allergy: string) => {
    setFormData((prev) => ({
      ...prev,
      allergies: prev.allergies.filter((a) => a !== allergy),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="space-y-8 max-w-4xl">
      {/* Header */}
      <div>
        <h1 className="text-xl font-bold tracking-tight text-[#14181C] dark:text-white">
          Settings & Profile Targets
        </h1>
        <p className="text-xs text-[#6E7781] dark:text-[#8B949E] mt-0.5">
          Configure body biometric targets, dietary rules, and cooking preferences.
        </p>
      </div>

      {/* Sustainability & Food Waste Tracker Card */}
      <div className="p-5 rounded-2xl border border-[#3E7C6B]/30 bg-[#3E7C6B]/5 dark:bg-[#3E7C6B]/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-[#3E7C6B]/20 text-[#3E7C6B] dark:text-teal-400">
            <Leaf className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-[#14181C] dark:text-white">
              Food Waste Prevention Impact
            </div>
            <div className="text-xs text-[#57606A] dark:text-[#8B949E]">
              By cooking pantry items before expiration, you have saved an estimated:
            </div>
          </div>
        </div>

        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="text-2xl font-extrabold tabular-nums text-[#3E7C6B] dark:text-teal-400">
              ${foodWasteStats.estimatedMoneySaved.toFixed(0)}
            </div>
            <span className="text-[10px] text-[#6E7781] dark:text-[#8B949E] uppercase font-bold">
              Groceries Saved
            </span>
          </div>

          <div className="text-right border-l border-[#3E7C6B]/20 pl-6">
            <div className="text-2xl font-extrabold tabular-nums text-[#3E7C6B] dark:text-teal-400">
              {foodWasteStats.estimatedKgSaved} kg
            </div>
            <span className="text-[10px] text-[#6E7781] dark:text-[#8B949E] uppercase font-bold">
              Food Saved
            </span>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Biometrics & Personal Info */}
        <div className="p-6 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] space-y-4">
          <h2 className="text-sm font-bold text-[#14181C] dark:text-white pb-2 border-b border-[#EAECEF] dark:border-[#21262D]">
            Athlete Biometrics
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Full Name
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Age
              </label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => handleInputChange('age', parseInt(e.target.value) || 25)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Sex
              </label>
              <select
                value={formData.sex}
                onChange={(e) => handleInputChange('sex', e.target.value)}
                className="w-full px-2.5 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              >
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Height (cm)
              </label>
              <input
                type="number"
                value={formData.heightCm}
                onChange={(e) => handleInputChange('heightCm', parseFloat(e.target.value) || 175)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Weight (kg)
              </label>
              <input
                type="number"
                step="0.1"
                value={formData.weightKg}
                onChange={(e) => handleInputChange('weightKg', parseFloat(e.target.value) || 75)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Activity Level
              </label>
              <select
                value={formData.activityLevel}
                onChange={(e) => handleInputChange('activityLevel', e.target.value as ActivityLevel)}
                className="w-full px-2.5 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              >
                <option value="sedentary">Sedentary (desk job)</option>
                <option value="lightly_active">Lightly Active (1-3 days/wk)</option>
                <option value="moderately_active">Moderately Active (3-5 days/wk)</option>
                <option value="very_active">Very Active (6-7 days/wk)</option>
                <option value="extra_active">Extra Active (intense/athlete)</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Fitness Goal
              </label>
              <select
                value={formData.goal}
                onChange={(e) => handleInputChange('goal', e.target.value as FitnessGoal)}
                className="w-full px-2.5 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden capitalize"
              >
                <option value="lose_fat">Lose Fat</option>
                <option value="maintain">Maintain</option>
                <option value="build_muscle">Build Muscle</option>
              </select>
            </div>
          </div>
        </div>

        {/* Daily Macro Targets with Auto-Calculator & Manual Overrides */}
        <div className="p-6 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-2 border-b border-[#EAECEF] dark:border-[#21262D]">
            <div>
              <h2 className="text-sm font-bold text-[#14181C] dark:text-white">
                Daily Macro Targets
              </h2>
              <p className="text-[11px] text-[#6E7781] dark:text-[#8B949E]">
                Calculate suggested numbers from your BMR/TDEE or manually type exact values.
              </p>
            </div>

            <button
              type="button"
              onClick={handleRecalculateAutoTargets}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E2E4E8] dark:border-[#30363D] text-[#14181C] dark:text-white text-xs font-semibold hover:bg-slate-50 dark:hover:bg-[#21262D] transition-colors cursor-pointer"
            >
              <Calculator className="w-3.5 h-3.5 text-[#D4A017]" />
              <span>Auto-Calculate Suggested</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            {/* Calories */}
            <div className="p-3 rounded-xl border border-[#E2E4E8] dark:border-[#22272E] bg-[#F6F8FA] dark:bg-[#0D1117]">
              <label className="text-[10px] uppercase font-bold text-[#6E7781] block mb-1">
                Calories (kcal)
              </label>
              <input
                type="number"
                value={formData.targets.calories}
                onChange={(e) => handleMacroChange('calories', e.target.value)}
                className="w-full text-lg font-extrabold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            {/* Protein */}
            <div className="p-3 rounded-xl border border-[#A6243D]/30 bg-[#A6243D]/5 dark:bg-[#A6243D]/10">
              <label className="text-[10px] uppercase font-bold text-[#A6243D] dark:text-rose-400 block mb-1">
                Protein (grams)
              </label>
              <input
                type="number"
                value={formData.targets.protein}
                onChange={(e) => handleMacroChange('protein', e.target.value)}
                className="w-full text-lg font-extrabold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            {/* Carbs */}
            <div className="p-3 rounded-xl border border-[#D4A017]/30 bg-[#D4A017]/5 dark:bg-[#D4A017]/10">
              <label className="text-[10px] uppercase font-bold text-[#D4A017] dark:text-amber-400 block mb-1">
                Carbohydrates (grams)
              </label>
              <input
                type="number"
                value={formData.targets.carbs}
                onChange={(e) => handleMacroChange('carbs', e.target.value)}
                className="w-full text-lg font-extrabold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            {/* Fat */}
            <div className="p-3 rounded-xl border border-[#3E7C6B]/30 bg-[#3E7C6B]/5 dark:bg-[#3E7C6B]/10">
              <label className="text-[10px] uppercase font-bold text-[#3E7C6B] dark:text-teal-400 block mb-1">
                Fat (grams)
              </label>
              <input
                type="number"
                value={formData.targets.fat}
                onChange={(e) => handleMacroChange('fat', e.target.value)}
                className="w-full text-lg font-extrabold tabular-nums bg-transparent text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>
          </div>
        </div>

        {/* Dietary Preferences & Allergies */}
        <div className="p-6 rounded-2xl border border-[#E2E4E8] dark:border-[#22272E] bg-white dark:bg-[#161B22] space-y-4">
          <h2 className="text-sm font-bold text-[#14181C] dark:text-white pb-2 border-b border-[#EAECEF] dark:border-[#21262D]">
            Dietary Guidelines & Cooking Style
          </h2>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E] block">
              Dietary Patterns
            </label>
            <div className="flex flex-wrap gap-2">
              {DIETARY_OPTIONS.map((opt) => {
                const isSelected = formData.dietaryPreferences.includes(opt);
                return (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => toggleDietaryPref(opt)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-[#14181C] dark:bg-white text-white dark:text-[#14181C] font-semibold'
                        : 'border border-[#E2E4E8] dark:border-[#30363D] text-[#57606A] dark:text-[#8B949E] hover:bg-slate-100 dark:hover:bg-[#21262D]'
                    }`}
                  >
                    {opt.replace('-', ' ')}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Allergies management */}
          <div className="space-y-2 pt-2">
            <label className="text-xs font-semibold text-[#57606A] dark:text-[#8B949E] block">
              Allergies & Intolerances to Exclude
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {formData.allergies.map((allergy) => (
                <span
                  key={allergy}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-md bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-900/50"
                >
                  <span>{allergy}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveAllergy(allergy)}
                    className="hover:text-red-900 font-bold"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>

            <div className="flex gap-2 max-w-sm">
              <input
                type="text"
                placeholder="Add allergy (e.g. Peanuts, Shellfish)..."
                value={newAllergy}
                onChange={(e) => setNewAllergy(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddAllergy(e);
                  }
                }}
                className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              />
              <button
                type="button"
                onClick={handleAddAllergy}
                className="px-3 py-1.5 text-xs font-semibold rounded-xl bg-slate-200 dark:bg-[#21262D] text-[#14181C] dark:text-white"
              >
                Add
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-3 border-t border-[#EAECEF] dark:border-[#21262D]">
            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Cooking Skill Level
              </label>
              <select
                value={formData.cookingSkill}
                onChange={(e) => handleInputChange('cookingSkill', e.target.value as CookingSkill)}
                className="w-full px-2.5 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden capitalize"
              >
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Household Size (Servings)
              </label>
              <input
                type="number"
                min="1"
                max="10"
                value={formData.householdSize}
                onChange={(e) => handleInputChange('householdSize', parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-medium text-[#57606A] dark:text-[#8B949E]">
                Time Budget for Cooking
              </label>
              <select
                value={formData.timeBudget}
                onChange={(e) => handleInputChange('timeBudget', e.target.value as TimeBudget)}
                className="w-full px-2.5 py-2 text-xs rounded-xl border border-[#E1E4E8] dark:border-[#30363D] bg-white dark:bg-[#0D1117] text-[#14181C] dark:text-white focus:outline-hidden"
              >
                <option value="under 15 min">Under 15 min</option>
                <option value="15-30 min">15-30 min</option>
                <option value="30-60 min">30-60 min</option>
                <option value="no limit">No limit</option>
              </select>
            </div>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex items-center justify-end gap-3 pt-2">
          {saveSuccess && (
            <span className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-semibold animate-in fade-in">
              <Check className="w-4 h-4" />
              <span>Targets Saved Successfully</span>
            </span>
          )}

          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#14181C] hover:bg-[#252B33] dark:bg-white dark:hover:bg-slate-200 text-white dark:text-[#14181C] text-xs font-bold transition-colors cursor-pointer shadow-md"
          >
            <Save className="w-4 h-4" />
            <span>Save Profile Targets</span>
          </button>
        </div>
      </form>
    </div>
  );
};
