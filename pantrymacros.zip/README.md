# PantryMacros

A desktop-first fitness nutrition web application that combines daily macro tracking with an AI-powered pantry scanner that suggests recipes fitting the user's remaining macros for the day.

## Features
- **Macro Tracker**: Real-time concentric rings for calories, protein (`#A6243D`), carbs (`#D4A017`), and fat (`#3E7C6B`).
- **AI Pantry Scanner**: Multi-photo upload with vision recognition and an editable checklist step.
- **AI Recipe Engine**: 3-column side-by-side recipes formatted like printed cards with scalable servings, "Cook This" pantry decrements, and "Log This Meal" one-tap tracking.
- **Interactive Cook Mode**: Fullscreen step-by-step guidance with built-in timers.
- **Smart Grocery List**: Automatic missing ingredient lists with clipboard and print exports.
- **Trends & Weight Progression**: Weekly intake charts and scale weigh-in tracking.

## Files
- `standalone.html`: Complete, self-contained single-file HTML version ready to paste into GitHub or host on GitHub Pages without any build steps.
- Full full-stack TypeScript React codebase with Express backend in `src/` and `server.ts`.
